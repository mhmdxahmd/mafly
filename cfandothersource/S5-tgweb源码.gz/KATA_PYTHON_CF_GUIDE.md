# Kata 容器 (Python 环境) + Cloudflare 端口回溯极速部署指南

本文档介绍如何在 Kata 翼龙容器（Python 3 环境）中运行双核 Telegram WebProxy，并通过 Cloudflare 的端口回溯机制（Origin Rules 或 Worker）将公网标准的 443 HTTPS 端口转发到 Kata 的高位随机端口。

---

## 一、架构工作流

```
Telegram 客户端 (443 端口 / HTTPS / WSS)
                 │
                 ▼
      Cloudflare 边缘节点 (443 终结 TLS 证书)
                 │
                 │ 端口回溯映射 (将 443 重写回源至 Kata 随机端口)
                 ▼
      Kata 容器 (Python 调度 + 官方 tproxy-server + teleproxy)
                 │
                 ▼
         Telegram 官方 DC 数据中心
```

---

## 二、第一部分：Kata 容器部署 (Python 环境)

### 1. 准备运行环境
在 Kata 翼龙面板创建容器或切换环境时，确保运行镜像选择 **Python 3**（例如 Python 3.10+）。控制台启动命令设置为：
```bash
python app.py
```

### 2. 上传核心文件
打开 Kata 容器的 SFTP 文件管理器，清空无关旧文件，仅上传以下 3 个文件到容器根目录 `/home/container/`：
1. **app.py**：调度主控与监控页面（零外部第三方依赖，无需 pip install）
2. **tproxy-server**：官方协议 Web 桥接二进制（本地源文件为 `scratch/tproxy-server/tproxy-server-linux`，上传后必须去掉 `-linux` 后缀）
3. **teleproxy**：MTProto 直连后端二进制（本地源文件为 `scratch/teleproxy`）

### 3. 启动并获取端口
在 Kata 控制台点击 **Start** 启动容器。
观察控制台日志输出，记录两项关键信息：
- 当前分配的公网访问地址与随机端口（例如：`fr-node-46.katabump.com:20255` 或 IP 端口 `51.75.118.151:20255`）
- 启动日志中显示的 Secret（默认值为：`473ce5d4958eb5f968c87680a23854a0`）

---

## 三、第二部分：Cloudflare 端口回溯配置

Telegram WebProxy 客户端严格要求连接标准的 443 端口，而 Kata 容器分配的是高位随机端口（如 20255）。通过 Cloudflare 即可免费实现 443 端口自动回溯转发。

### Cloudflare Origin Rules 回源规则（端口回溯）

该方案基于 Cloudflare 传输层原生端口映射，**直接支持裸 IP 解析**，免写代码，原生支持 WebSocket 双向数据流且无任何域名阻断风险：

1. **配置 DNS 解析（直接支持裸 IP）**：
进入 Cloudflare 域名控制台 -> **DNS** -> **Records**。
添加一条 `A` 记录（如 `tg.yourdomain.com`），IPv4 地址直接填写 Kata 容器的实际公网 IP（例如 `51.75.118.151`）。
**必须开启橙色小云朵（Proxied / 已代理）**。

2. **创建端口回源重写规则**：
在域名左侧菜单进入 **Rules** -> **Origin Rules (回源规则)**。
点击 **Create rule (创建规则)**。
- Rule name (规则名称)：`tg-port-rewrite`
- Field (字段)：`Hostname`
- Operator (运算符)：`equals`
- Value (值)：填写你的二级域名，例如 `tg.yourdomain.com`
- Destination port (目标端口)：选择 **Rewrite to... (重写为)**，填入 Kata 容器分配的实际端口（例如 `20255`）

3. **保存并生效**：
点击 **Deploy (部署)**。此时任何访问 `https://tg.yourdomain.com`（标准 443 端口）的流量，都会被 Cloudflare 边缘节点自动回溯转换为目标端口 `20255` 并转发至容器。

---

## 四、客户端导入使用

在 Telegram Desktop、iOS 或 Android 客户端中，打开以下格式的链接即可一键连通：

```text
tg://webproxy?server=tg.yourdomain.com&secret=473ce5d4958eb5f968c87680a23854a0
```

- 将 `tg.yourdomain.com` 替换为你配置好的 443 二级域名。
- 密钥使用 32 位 Hex 纯密钥 `473ce5d4958eb5f968c87680a23854a0`。
- 浏览器直接访问 `https://tg.yourdomain.com` 即可实时查看在线连接数、上下行流量及系统状态面板。
