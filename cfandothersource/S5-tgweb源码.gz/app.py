import socket
import os
import sys
import time
import json
import hmac
import hashlib
import base64
import asyncio
import subprocess
import logging
from http.server import HTTPServer, BaseHTTPRequestHandler
import urllib.request
from urllib.parse import urlparse, parse_qs

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("TG-WebRelay-Kata")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PORT = int(os.getenv("SERVER_PORT") or os.getenv("PORT") or "20255")
INTERNAL_SITE_PORT = 20256
MTPROXY_INTERNAL_PORT = 2398
SECRET = os.getenv("SECRET", "473ce5d4958eb5f968c87680a23854a0")
HOSTNAME = os.getenv("TG_HOST", "tgweb.ehb.cc.cd")

START_TIME = time.time()
STATS = {
    "active_connections": 0,
    "total_sessions": 0,
    "total_bytes_rx": 0,
    "total_bytes_tx": 0
}

def format_bytes(size):
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size < 1024.0:
            return f"{size:.2f} {unit}"
        size /= 1024.0
    return f"{size:.2f} PB"

def format_uptime():
    elapsed = int(time.time() - START_TIME)
    days = elapsed // 86400
    hours = (elapsed % 86400) // 3600
    minutes = (elapsed % 3600) // 60
    if days > 0:
        return f"{days}天 {hours}小时"
    if hours > 0:
        return f"{hours}小时 {minutes}分"
    return f"{minutes}分钟"

def get_container_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
        if ip: return ip
    except Exception:
        pass
    try:
        hip = socket.gethostbyname(socket.gethostname())
        if hip: return hip
    except Exception:
        pass
    return "172.19.0.200"

# 构建 Element UI 主页 HTML
def render_home_html():
    webproxy_link = f"tg://webproxy?server={HOSTNAME}&secret={SECRET}"
    mtproto_link = f"tg://proxy?server=51.75.118.151&port=20255&secret={SECRET}"
    group_link = os.getenv("TG_GROUP", "https://t.me/s5gydl")
    
    total_bytes = STATS["total_bytes_rx"] + STATS["total_bytes_tx"]
    cur_traffic = format_bytes(total_bytes)
    cur_uptime = format_uptime()

    return f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Telegram 官方代理服务中心</title>
<style>
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    background-color: #f0f2f5;
    color: #303133;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    padding: 24px 16px;
  }}
  .container {{
    width: 100%;
    max-width: 540px;
    background-color: #ffffff;
    border: 1px solid #dcdfe6;
    border-radius: 6px;
    box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.05);
    overflow: hidden;
  }}
  .header {{
    padding: 24px 28px 16px;
    border-bottom: 1px solid #ebeef5;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }}
  .title {{
    font-size: 18px;
    font-weight: 600;
    color: #303133;
  }}
  .badge-success {{
    background-color: #f0f9eb;
    color: #67c23a;
    border: 1px solid #e1f3d8;
    font-size: 12px;
    padding: 4px 8px;
    border-radius: 4px;
    font-weight: 500;
  }}
  .content {{
    padding: 24px 28px;
  }}
  .card-section {{
    margin-bottom: 22px;
  }}
  .section-label {{
    font-size: 13px;
    color: #909399;
    margin-bottom: 8px;
    font-weight: 500;
  }}
  .proxy-card {{
    background: #fdfdfd;
    border: 1px solid #ebeef5;
    border-radius: 4px;
    padding: 14px 16px;
  }}
  .proxy-url-text {{
    font-family: Consolas, Monaco, monospace;
    font-size: 13px;
    color: #409eff;
    background: #ecf5ff;
    padding: 8px 10px;
    border-radius: 4px;
    border: 1px solid #d9ecff;
    word-break: break-all;
    user-select: all;
    margin-bottom: 10px;
  }}
  .proxy-details {{
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 8px;
    font-size: 13px;
    margin-bottom: 12px;
  }}
  .detail-item {{
    display: flex;
    flex-direction: column;
  }}
  .detail-label {{
    color: #909399;
    font-size: 11px;
    margin-bottom: 2px;
  }}
  .detail-value {{
    font-family: Consolas, Monaco, monospace;
    color: #303133;
    font-weight: 500;
    word-break: break-all;
  }}
  .btn-group {{
    display: flex;
    gap: 8px;
    margin-top: 8px;
  }}
  .btn {{
    padding: 8px 16px;
    font-size: 13px;
    border-radius: 4px;
    cursor: pointer;
    border: 1px solid transparent;
    transition: all 0.2s;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-weight: 500;
  }}
  .btn-primary {{
    background-color: #409eff;
    color: #ffffff;
    border-color: #409eff;
  }}
  .btn-primary:hover {{
    background-color: #66b1ff;
    border-color: #66b1ff;
  }}
  .btn-default {{
    background-color: #ffffff;
    color: #606266;
    border-color: #dcdfe6;
  }}
  .btn-default:hover {{
    color: #409eff;
    border-color: #c6e2ff;
    background-color: #ecf5ff;
  }}
  .btn-success {{
    background-color: #67c23a;
    color: #ffffff;
    border-color: #67c23a;
  }}
  .btn-success:hover {{
    background-color: #85ce61;
    border-color: #85ce61;
  }}
  .metrics-grid {{
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 12px;
    margin-top: 8px;
  }}
  .metric-card {{
    background: #fafafa;
    border: 1px solid #ebeef5;
    border-radius: 4px;
    padding: 12px;
    text-align: center;
  }}
  .metric-title {{
    font-size: 12px;
    color: #909399;
    margin-bottom: 4px;
  }}
  .metric-value {{
    font-family: Consolas, Monaco, monospace;
    font-size: 17px;
    font-weight: 600;
    color: #303133;
  }}
  .metric-unit {{
    font-size: 12px;
    color: #909399;
    font-weight: normal;
  }}
  .metric-sub {{
    font-size: 11px;
    color: #c0c4cc;
    margin-top: 2px;
  }}
  .group-box {{
    background: #fdfdfd;
    border: 1px solid #ebeef5;
    border-radius: 4px;
    padding: 16px;
  }}
  .group-text {{
    font-size: 13px;
    color: #606266;
    line-height: 1.5;
    margin-bottom: 12px;
  }}
  .toast {{
    position: fixed;
    top: 24px;
    left: 50%;
    transform: translateX(-50%);
    background: #303133;
    color: #ffffff;
    padding: 8px 16px;
    border-radius: 4px;
    font-size: 13px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    display: none;
    z-index: 1000;
  }}
  .toast.show {{
    display: block;
    animation: fadeInOut 2s ease forwards;
  }}
  @keyframes fadeInOut {{
    0% {{ opacity: 0; transform: translate(-50%, -10px); }}
    15% {{ opacity: 1; transform: translate(-50%, 0); }}
    85% {{ opacity: 1; transform: translate(-50%, 0); }}
    100% {{ opacity: 0; transform: translate(-50%, -10px); }}
  }}
</style>
</head>
<body>

<div id="toast" class="toast">复制成功</div>

<div class="container">
  <div class="header">
    <div class="title">Telegram 代理服务中心</div>
    <div class="badge-success">● 服务就绪 (Online)</div>
  </div>
  
  <div class="content">
    <!-- 方式一：全新 WEB Proxy 协议 -->
    <div class="card-section">
      <div class="section-label">1. 推荐方式：Telegram WEB 代理 (官方全新通道，抗封锁)</div>
      <div class="proxy-card">
        <div class="proxy-url-text" id="webproxy-link-text">{webproxy_link}</div>
        <div class="proxy-details">
          <div class="detail-item">
            <span class="detail-label">服务器域名</span>
            <span class="detail-value">{HOSTNAME}</span>
          </div>
          <div class="detail-item">
            <span class="detail-label">传输协议</span>
            <span class="detail-value">HTTPS / WebSocket</span>
          </div>
          <div class="detail-item" style="grid-column: span 2;">
            <span class="detail-label">32位专属密钥</span>
            <span class="detail-value">{SECRET}</span>
          </div>
        </div>
        <div class="btn-group">
          <a href="{webproxy_link}" class="btn btn-primary">一键导入连接</a>
          <button class="btn btn-default" onclick="copyText('{webproxy_link}', 'WEB 完整链接已复制')">复制完整连接</button>
        </div>
      </div>
    </div>

    <!-- 方式二：节点负载与实时监控 (Prometheus) -->
    <div class="card-section">
      <div class="section-label">2. 节点负载与实时监控 (Prometheus 实时采集)</div>
      <div class="metrics-grid">
        <div class="metric-card">
          <div class="metric-title">当前在线人数</div>
          <div class="metric-value" id="val-online" style="color: #67c23a;">0 <span class="metric-unit">人</span></div>
          <div class="metric-sub">实时并发连接</div>
        </div>
        <div class="metric-card">
          <div class="metric-title">累计加密吞吐</div>
          <div class="metric-value" id="val-traffic" style="color: #409eff;">0.00 B</div>
          <div class="metric-sub">双向总传输量</div>
        </div>
        <div class="metric-card">
          <div class="metric-title">累计建立会话</div>
          <div class="metric-value" id="val-sessions">0 <span class="metric-unit">次</span></div>
          <div class="metric-sub">总接入 Sessions</div>
        </div>
        <div class="metric-card">
          <div class="metric-title">持续稳定运行</div>
          <div class="metric-value" id="val-uptime" style="font-size: 15px;">{cur_uptime}</div>
          <div class="metric-sub">无宕机健康守护</div>
        </div>
      </div>
    </div>

    <!-- 方式三：官方交流群组 -->
    <div class="card-section" style="margin-bottom: 0;">
      <div class="section-label">3. 官方交流群组</div>
      <div class="group-box">
        <div class="group-text">欢迎加入官方交流群 <b>@s5gydl</b>，获取实时节点状态、测速通知与最新专属配置！</div>
        <div class="btn-group" style="margin-top: 0;">
          <a href="{group_link}" target="_blank" class="btn btn-success">立即加入群组 (@s5gydl)</a>
          <button class="btn btn-default" onclick="copyText('{group_link}', '群组链接已复制')">复制群链接</button>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
function copyText(text, msg) {{
  if (navigator.clipboard && navigator.clipboard.writeText) {{
    navigator.clipboard.writeText(text).then(function() {{
      showToast(msg || '复制成功');
    }}).catch(function() {{
      fallbackCopy(text, msg);
    }});
  }} else {{
    fallbackCopy(text, msg);
  }}
}}

function fallbackCopy(text, msg) {{
  var input = document.createElement('input');
  input.setAttribute('value', text);
  document.body.appendChild(input);
  input.select();
  document.execCommand('copy');
  document.body.removeChild(input);
  showToast(msg || '复制成功');
}}

function showToast(msg) {{
  var toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.classList.add('show');
  setTimeout(function() {{
    toast.classList.remove('show');
  }}, 2000);
}}

function updateMetrics() {{
  fetch('/api/stats')
    .then(function(res) {{ return res.json(); }})
    .then(function(data) {{
      var onlineEl = document.getElementById('val-online');
      var trafficEl = document.getElementById('val-traffic');
      var sessEl = document.getElementById('val-sessions');
      var uptimeEl = document.getElementById('val-uptime');
      if (onlineEl) onlineEl.innerHTML = data.active_connections + ' <span class="metric-unit">人</span>';
      if (trafficEl) trafficEl.textContent = data.total_traffic;
      if (sessEl) sessEl.innerHTML = data.total_sessions + ' <span class="metric-unit">次</span>';
      if (uptimeEl) uptimeEl.textContent = data.uptime;
    }})
    .catch(function() {{}});
}}
setInterval(updateMetrics, 3000);
</script>

</body>
</html>"""

# Python 内部 HTTP 服务 (处理普通网页访问与指标，由 tproxy-server 反向代理至此)
class SiteHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/api/stats":
            online = 0
            sessions = 0
            bytes_up = 0
            bytes_down = 0
            try:
                req = urllib.request.Request("http://127.0.0.1:20257/metrics")
                with urllib.request.urlopen(req, timeout=1.5) as resp:
                    raw = resp.read().decode("utf-8", errors="ignore")
                    for line in raw.splitlines():
                        parts = line.strip().split()
                        if len(parts) == 2:
                            k, v = parts[0], parts[1]
                            if k == "tproxy_sessions_live":
                                online = int(v)
                            elif k == "tproxy_sessions_created_total":
                                sessions = int(v)
                            elif k == "tproxy_bytes_up_total":
                                bytes_up = int(v)
                            elif k == "tproxy_bytes_down_total":
                                bytes_down = int(v)
            except Exception:
                pass
            
            total_traffic = format_bytes(bytes_up + bytes_down)
            data = {
                "active_connections": online,
                "total_sessions": sessions,
                "total_traffic": total_traffic,
                "uptime": format_uptime()
            }
            body = json.dumps(data).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        if parsed.path in ["/healthz", "/status"]:
            body = b'{"status":"ok","engine":"official-tproxy"}\n'
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        # 默认返回主页
        html = render_home_html().encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(html)))
        self.end_headers()
        self.wfile.write(html)

    def log_message(self, format, *args):
        # 静默常规探测日志
        return

def start_site_server():
    server = HTTPServer(("127.0.0.1", INTERNAL_SITE_PORT), SiteHandler)
    logger.info(f"Internal Site Handler running on 127.0.0.1:{INTERNAL_SITE_PORT}")
    server.serve_forever()

def main():
    logger.info(f"Target Port: {PORT}")
    logger.info(f"Active 32-bit Secret: {SECRET}")
    logger.info(f"Target Hostname: {HOSTNAME}")

    container_ip = get_container_ip()
    logger.info(f"Detected Container IP: {container_ip}")

    # 1. 启动 teleproxy
    teleproxy_bin = os.path.join(BASE_DIR, "teleproxy")
    teleproxy_proc = None
    if os.path.exists(teleproxy_bin):
        try:
            os.chmod(teleproxy_bin, 0o755)
        except Exception:
            pass
        logger.info(f"Starting teleproxy on -H {MTPROXY_INTERNAL_PORT} (--direct mode)...")
        teleproxy_proc = subprocess.Popen([
            teleproxy_bin,
            "-S", SECRET,
            "-H", str(MTPROXY_INTERNAL_PORT),
            "--direct"
        ])
        logger.info(f"teleproxy started with PID {teleproxy_proc.pid}")
        time.sleep(0.5)

    # 2. 配置并启动官方 tproxy-server
    tproxy_bin = os.path.join(BASE_DIR, "tproxy-server")
    tproxy_proc = None
    if os.path.exists(tproxy_bin):
        try:
            os.chmod(tproxy_bin, 0o755)
        except Exception:
            pass

        # 保证 token.key 存在
        token_key_path = os.path.join(BASE_DIR, "token.key")
        if not os.path.exists(token_key_path) or os.path.getsize(token_key_path) != 32:
            with open(token_key_path, "wb") as f:
                f.write(os.urandom(32))
        try:
            os.chmod(token_key_path, 0o600)
        except Exception:
            pass

        # 写入 profiles.json
        profiles_path = os.path.join(BASE_DIR, "profiles.json")
        profiles_data = {
            "profiles": [
                {
                    "name": "default",
                    "secret": SECRET,
                    "backend": f"{container_ip}:{MTPROXY_INTERNAL_PORT}",
                    "carrier_mode": "websocket-lanes"
                }
            ]
        }
        with open(profiles_path, "w", encoding="utf-8") as f:
            json.dump(profiles_data, f, indent=2)
        try:
            os.chmod(profiles_path, 0o600)
        except Exception:
            pass

        # 写入 tproxy_config.json
        config_path = os.path.join(BASE_DIR, "tproxy_config.json")
        config_data = {
            "public_hostname": HOSTNAME,
            "listen": f"0.0.0.0:{PORT}",
            "admin_listen": "127.0.0.1:20257",
            "public_upstream": f"http://127.0.0.1:{INTERNAL_SITE_PORT}",
            "token_key_file": token_key_path,
            "static_routes": "exact",
            "profiles_file": profiles_path,
            "enable_pprof": False,
            "limits": {
                "max_header_bytes": 32768,
                "max_body_bytes": 2097152,
                "max_frame_payload": 1048576,
                "carrier_batch_bytes": 2097152,
                "max_streams_per_session": 256,
                "max_closed_stream_ids": 16384,
                "max_pending_per_session": 67108864,
                "max_pending_global": 2147483648,
                "max_pending_items_per_session": 32768,
                "max_pending_items_global": 1048576,
                "max_sessions_per_ip": 0,
                "max_sessions_global": 1024,
                "max_streams_global": 32768,
                "max_backend_dials_in_flight": 1024,
                "new_sessions_per_minute": 6000,
                "new_sessions_burst": 1024,
                "new_streams_per_minute": 60000,
                "new_streams_burst": 4096,
                "max_bootstraps_per_ip": 0,
                "max_bootstraps_global": 4096,
                "new_bootstraps_per_minute": 12000,
                "new_bootstraps_burst": 2048,
                "max_profiles": 32
            },
            "timeouts": {
                "backend_dial": "10s",
                "long_poll": "15s",
                "reconnect_grace": "5m",
                "bootstrap_lifetime": "5m",
                "read_header": "15s",
                "idle": "120s",
                "shutdown": "15s"
            }
        }
        with open(config_path, "w", encoding="utf-8") as f:
            json.dump(config_data, f, indent=2)

        logger.info(f"Starting official tproxy-server listening on 0.0.0.0:{PORT}...")
        tproxy_proc = subprocess.Popen([
            tproxy_bin,
            "-config", config_path
        ])
        logger.info(f"tproxy-server started successfully with PID {tproxy_proc.pid}")

    # 3. 在主线程启动内部站点服务
    try:
        start_site_server()
    finally:
        if tproxy_proc:
            tproxy_proc.terminate()
        if teleproxy_proc:
            teleproxy_proc.terminate()

if __name__ == "__main__":
    main()
