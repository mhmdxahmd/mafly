#!/usr/bin/env node
/**
 * 🚀 S5公益代理 - 现代化 SOCKS5 代理用户门户系统
 * 包含：原生 SOCKS5、单端口复用、邀请返利机制、精美 UI 面板、邮件验证码登录
 */

const fs = require('fs');
const http = require('http');
const net = require('net');
const dns = require('dns');
const path = require('path');
const crypto = require('crypto');

// 极致极速：绕过 Node.js libuv 底层默认仅有 4 个线程的 getaddrinfo 阻塞池！
// 直接使用真实网络层异步 DNS (dns.promises.resolve4/6) + 并发请求合并 + 内存级秒级缓存
const dnsPromises = dns.promises;
const dnsCache = new Map();
const dnsPending = new Map();

const extremeResolveDns = async (hostname) => {
  // 1. 命中缓存，零延迟返回 (0ms)
  const cached = dnsCache.get(hostname);
  if (cached && Date.now() < cached.expiry) return cached.ip;

  // 2. 高并发下同一个域名只发起一次真实网络请求
  if (dnsPending.has(hostname)) return dnsPending.get(hostname);

  const p = (async () => {
    try {
      // 3. 优先异步无阻塞解析 IPv4（速度最快，兼容性最好）
      const ips = await dnsPromises.resolve4(hostname);
      if (ips && ips.length > 0) return ips[0];
    } catch (e) {
      try {
        // 4. 备用异步解析 IPv6
        const ipv6s = await dnsPromises.resolve6(hostname);
        if (ipv6s && ipv6s.length > 0) return ipv6s[0];
      } catch (e2) {
        // 5. 终极兜底：调用 OS 底层 lookup
        return new Promise((res, rej) => dns.lookup(hostname, (err, ip) => err ? rej(err) : res(ip)));
      }
    }
    throw new Error('DNS Fail');
  })();

  dnsPending.set(hostname, p);
  try {
    const ip = await p;
    dnsCache.set(hostname, { ip, expiry: Date.now() + 60000 }); // 缓存 60 秒
    return ip;
  } finally {
    dnsPending.delete(hostname);
  }
};

setInterval(() => {
  const now = Date.now();
  for (const [k, v] of dnsCache) { if (now >= v.expiry) dnsCache.delete(k); }
}, 60000).unref();

let nodemailer;
try { nodemailer = require('nodemailer'); } catch (e) { }

// ========== 全局配置 & 数据存储 ==========
const CONFIG = {
  port: parseInt(process.env.SERVER_PORT || process.env.PORT) || 20084,
  dataFile: path.join(__dirname, 'proxy_users.json'),
  settingsFile: path.join(__dirname, 'proxy_settings.json'),
  adminPassword: process.env.ADMIN_PASS || '123456',
  saveInterval: 10000
};

let globalAccounts = [];
// 账户 Map 索引：O(1) 查找，替代 O(n) 的 Array.find
// key = 'username:password'（SOCKS5 认证用）
const accountByAuth = new Map();
// key = username（Web token 验证用）
const accountByName = new Map();
// 每用户活跃连接计数
const userConnCount = new Map();
const MAX_CONN_PER_USER = 5000; // 提速核心优化：放开并发连接数。现代网页（如 YouTube/Twitter）瞬间并发可达 100~300+，原先的 50 会导致严重卡顿和图片加载失败。

// 防暴力破解：记录管理员登录失败次数 { 'ip': { count: 0, lockUntil: 0 } }
const adminLoginAttempts = new Map();

const rebuildIndex = () => {
  accountByAuth.clear();
  accountByName.clear();
  globalAccounts.forEach(a => {
    accountByAuth.set(`${a.username}:${a.password}`, a);
    accountByName.set(a.username, a);
  });
};
let globalSettings = {
  defaultQuota: 1024 * 1024 * 1024 * 1024,
  inviteReward: 100 * 1024 * 1024 * 1024,
  smtpHost: '',
  smtpPort: 465,
  smtpUser: '',
  smtpPass: '',
  smtpSender: 'S5 Proxy <no-reply@abcai.online>',
  announcementMode: 'disabled', // disabled | always | daily | new
  announcementId: '',           // unique ID for 'new' mode tracking
  announcementTitle: '',
  announcementContent: '',
  announcementTime: ''
};

// 验证码内存存储 { 'email@abc.com': { code: '123456', expiresAt: 123456789 } }
const vCodes = new Map();

let publicIp = '';
http.get('http://api.ipify.org', res => {
  res.on('data', chunk => publicIp += chunk);
}).on('error', () => { publicIp = '未知IP(请勿使用CDN域名)'; });

const generateInviteCode = () => crypto.randomBytes(3).toString('hex').toUpperCase();

const DataManager = {
  load() {
    try {
      if (fs.existsSync(CONFIG.settingsFile)) {
        globalSettings = { ...globalSettings, ...JSON.parse(fs.readFileSync(CONFIG.settingsFile, 'utf8')) };
      }
    } catch (e) { }

    if (!fs.existsSync(CONFIG.dataFile)) {
      const initial = [];
      fs.writeFileSync(CONFIG.dataFile, JSON.stringify(initial, null, 2));
      return initial;
    }
    try {
      let data = JSON.parse(fs.readFileSync(CONFIG.dataFile, 'utf8'));
      let modified = false;
      const invCounts = {};
      data.forEach(a => { if (a.invitedBy) invCounts[a.invitedBy] = (invCounts[a.invitedBy] || 0) + 1; });
      data.forEach(acc => {
        if (!acc.inviteCode) { acc.inviteCode = generateInviteCode(); modified = true; }
        // 旧账户迁移：补齐字段
        if (!acc.role) { acc.role = 'normal'; modified = true; }
        if (!acc.status) { acc.status = 'active'; modified = true; }
        if (!acc.lastUsed) { acc.lastUsed = Date.now(); modified = true; }
        if (!acc.createdAt) { acc.createdAt = Date.now(); modified = true; }
        // 邀请满 3 人自动 VIP
        if (acc.role !== 'vip' && (invCounts[acc.username] || 0) >= 3) {
          acc.role = 'vip';
          if (acc.status === 'silent') acc.status = 'active';
          modified = true;
        }
      });
      if (modified) fs.writeFileSync(CONFIG.dataFile, JSON.stringify(data, null, 2));
      return data;
    } catch (e) { return []; }
  },
  save(accounts) {
    // 脏标记：数据未变化则跳过写盘
    const json = JSON.stringify(accounts, null, 2);
    if (json === this._lastSaved) return;
    this._lastSaved = json;
    fs.writeFile(CONFIG.dataFile, json, 'utf8', (err) => {
      if (err) console.error('[DataManager] save error:', err.message);
    });
  },
  saveSettings() { fs.writeFileSync(CONFIG.settingsFile, JSON.stringify(globalSettings, null, 2), 'utf8'); }
};

globalAccounts = DataManager.load();
rebuildIndex();

// Admin token 预计算（避免每次 HTTP 请求重复 sha256）
const ADMIN_TOKEN = crypto.createHash('sha256').update(CONFIG.adminPassword).digest('hex');

// 优雅退出：进程终止时同步写盘，确保流量数据不丢失
const gracefulShutdown = (signal) => {
  console.log(`\n[${signal}] 正在保存数据并退出...`);
  try {
    fs.writeFileSync(CONFIG.dataFile, JSON.stringify(globalAccounts, null, 2), 'utf8');
    console.log('数据已保存，安全退出。');
  } catch (e) {
    console.error('退出时写盘失败:', e.message);
  }
  process.exit(0);
};
process.on('SIGINT', () => gracefulShutdown('SIGINT'));
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));

// ========== Web API 服务器 ==========
const httpServer = http.createServer((req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const pathName = url.pathname;

  if (req.method === 'GET' && pathName === '/') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(getHtml());
    return;
  }

  const getBody = () => new Promise(resolve => {
    let body = ''; req.on('data', c => body += c);
    req.on('end', () => { try { resolve(JSON.parse(body || '{}')); } catch (e) { resolve({}); } });
  });

  const sendJSON = (obj, status = 200) => {
    res.writeHead(status, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(obj));
  };

  const token = req.headers.authorization?.split(' ')[1];
  // 使用预计算的 admin token，避免每次请求重复 sha256
  const isAdmin = token === ADMIN_TOKEN;

  let currentUser = null;
  if (token && !isAdmin) {
    const parts = token.split('.');
    if (parts.length === 2) {
      const u = Buffer.from(parts[0], 'hex').toString();
      const p = Buffer.from(parts[1], 'hex').toString();
      // 使用 Map O(1) 查找替代 Array.find
      const acc = accountByName.get(u);
      if (acc && (acc.webPassword === p || (!acc.webPassword && acc.password === p))) {
        currentUser = acc;
      }
    }
  }

  // ========== 用户相关 API ==========
  if (pathName === '/api/config' && req.method === 'GET') {
    return sendJSON({ defaultQuota: globalSettings.defaultQuota, serverPort: CONFIG.port, serverIp: publicIp });
  }

  if (pathName === '/api/announcement' && req.method === 'GET') {
    if (globalSettings.announcementMode === 'disabled') return sendJSON({ mode: 'disabled' });
    return sendJSON({
      mode: globalSettings.announcementMode,
      id: globalSettings.announcementId || '',
      title: globalSettings.announcementTitle || '',
      content: globalSettings.announcementContent || '',
      time: globalSettings.announcementTime || ''
    });
  }

  if (pathName === '/api/send-code' && req.method === 'POST') {
    getBody().then(async data => {
      if (!nodemailer) return sendJSON({ error: '服务端暂未安装 nodemailer，请联系管理员执行 npm install nodemailer' }, 500);
      if (!globalSettings.smtpHost || !globalSettings.smtpUser) {
        return sendJSON({ error: '系统尚未配置 SMTP 邮件服务，无法发送验证码。请联系管理员！' }, 400);
      }
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(data.email)) return sendJSON({ error: '请输入有效的邮箱地址' }, 400);

      const code = Math.floor(100000 + Math.random() * 900000).toString();
      vCodes.set(data.email, { code, expiresAt: Date.now() + 5 * 60 * 1000 });

      try {
        const transporter = nodemailer.createTransport({
          host: globalSettings.smtpHost,
          port: parseInt(globalSettings.smtpPort) || 465,
          secure: parseInt(globalSettings.smtpPort) === 465,
          auth: { user: globalSettings.smtpUser, pass: globalSettings.smtpPass }
        });
        await transporter.sendMail({
          from: globalSettings.smtpSender || globalSettings.smtpUser,
          to: data.email,
          subject: 'S5公益代理 - 您的登录验证码',
          html: `<div style="font-family: sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e2e8f0; border-radius: 12px;">
                  <h3 style="color: #0f172a;">欢迎使用 S5公益代理</h3>
                  <p style="color: #64748b;">您的验证码是：</p>
                  <p style="font-size: 32px; font-weight: 800; color: #4f46e5; letter-spacing: 4px; margin: 20px 0;">${code}</p>
                  <p style="color: #64748b; font-size: 12px;">该验证码 5 分钟内有效。如非本人操作，请忽略此邮件。</p>
                 </div>`
        });
        sendJSON({ success: true });
      } catch (e) {
        sendJSON({ error: '邮件发送失败，请检查系统 SMTP 配置。' + e.message }, 500);
      }
    });
    return;
  }

  if (pathName === '/api/register' && req.method === 'POST') {
    getBody().then(data => {
      const { email, code, webPassword, inviteCode } = data;
      if (!email || !code || !webPassword) return sendJSON({ error: '请填写邮箱、验证码和登录密码' }, 400);

      const record = vCodes.get(email);
      if (!record || record.code !== code || Date.now() > record.expiresAt) {
        return sendJSON({ error: '验证码错误或已过期' }, 400);
      }

      // Bug Fix: 使用 Map O(1) 查重，替代 Array.find
      if (accountByName.has(email)) return sendJSON({ error: '该邮箱已注册，请直接登录' }, 400);

      if (email === 'admin' || email === 'admin@admin.com') return sendJSON({ error: '保留账号无法注册' }, 400);
      let inviter = null;
      if (inviteCode) inviter = globalAccounts.find(a => a.inviteCode === inviteCode.toUpperCase());

      vCodes.delete(email);

      acc = {
        username: email,
        password: crypto.randomBytes(4).toString('hex'),
        webPassword: webPassword,
        trafficLimit: globalSettings.defaultQuota,
        trafficUsed: 0,
        expiry: '永不过期',
        role: 'normal',
        status: 'active',
        lastUsed: Date.now(),
        createdAt: Date.now(),
        inviteCode: generateInviteCode(),
        invitedBy: inviter ? inviter.username : null
      };
      globalAccounts.push(acc);
      if (inviter) {
        inviter.trafficLimit += globalSettings.inviteReward;
        const currentInvites = globalAccounts.filter(a => a.invitedBy === inviter.username).length;
        if (currentInvites >= 3 && inviter.role !== 'vip') {
          inviter.role = 'vip';
          if (inviter.status === 'silent') inviter.status = 'active';
        }
      }
      accountByAuth.set(`${acc.username}:${acc.password}`, acc);
      accountByName.set(acc.username, acc);
      DataManager.save(globalAccounts);

      const t = Buffer.from(acc.username).toString('hex') + '.' + Buffer.from(acc.webPassword).toString('hex');
      sendJSON({ success: true, token: t, role: 'user' });
    });
    return;
  }

  if (pathName === '/api/login' && req.method === 'POST') {
    getBody().then(data => {
      const { email, webPassword } = data;
      if (!email || !webPassword) return sendJSON({ error: '请填写邮箱和密码' }, 400);

      // 使用 Map O(1) 查找替代 Array.find
      const acc = accountByName.get(email);
      if (!acc || !(acc.webPassword === webPassword || (!acc.webPassword && acc.password === webPassword))) {
        return sendJSON({ error: '邮箱或密码错误' }, 400);
      }

      if (!acc.webPassword) {
        acc.webPassword = webPassword;
        DataManager.save(globalAccounts);
      }

      const t = Buffer.from(acc.username).toString('hex') + '.' + Buffer.from(acc.webPassword).toString('hex');
      sendJSON({ success: true, token: t, role: 'user' });
    });
    return;
  }

  if (pathName === '/api/forgot-password' && req.method === 'POST') {
    getBody().then(data => {
      const { email, code, newWebPassword } = data;
      if (!email || !code || !newWebPassword) return sendJSON({ error: '请填写完整信息' }, 400);

      const record = vCodes.get(email);
      if (!record || record.code !== code || Date.now() > record.expiresAt) {
        return sendJSON({ error: '验证码错误或已过期' }, 400);
      }

      // 使用 Map O(1) 查找
      const acc = accountByName.get(email);
      if (!acc) return sendJSON({ error: '该邮箱未注册' }, 400);

      vCodes.delete(email);
      acc.webPassword = newWebPassword;
      DataManager.save(globalAccounts);

      sendJSON({ success: true });
    });
    return;
  }

  if (pathName === '/api/login-admin' && req.method === 'POST') {
    const clientIp = req.socket.remoteAddress;
    const attempt = adminLoginAttempts.get(clientIp) || { count: 0, lockUntil: 0 };

    // 检查是否已被封禁
    if (Date.now() < attempt.lockUntil) {
      const waitMins = Math.ceil((attempt.lockUntil - Date.now()) / 60000);
      return sendJSON({ error: `多次尝试失败，IP已被锁定。请等待 ${waitMins} 分钟后再试` }, 429);
    }

    getBody().then(data => {
      const inputPass = String(data.password || '');

      // 防范时序攻击 (Timing Attack)：对输入密码和真实密码进行哈希后使用 timingSafeEqual 比对
      const inputHash = crypto.createHash('sha256').update(inputPass).digest();
      const realHash = crypto.createHash('sha256').update(CONFIG.adminPassword).digest();

      let isMatch = false;
      try {
        isMatch = crypto.timingSafeEqual(inputHash, realHash);
      } catch (e) { isMatch = false; }

      if (isMatch) {
        adminLoginAttempts.delete(clientIp); // 登录成功，清空失败记录
        return sendJSON({ success: true, token: ADMIN_TOKEN, role: 'admin' });
      } else {
        // 记录失败次数，连续 5 次失败则锁定该 IP 15 分钟
        attempt.count += 1;
        if (attempt.count >= 5) {
          attempt.lockUntil = Date.now() + 15 * 60 * 1000;
        }
        adminLoginAttempts.set(clientIp, attempt);
        sendJSON({ error: '管理员密码错误' }, 401);
      }
    });
    return;
  }

  if (pathName === '/api/me' && req.method === 'GET') {
    if (isAdmin) return sendJSON({ role: 'admin' });
    if (!currentUser) return sendJSON({ error: '未登录' }, 401);

    const formatSize = (bytes) => {
      if (isNaN(bytes) || bytes === 0) return '0 B';
      const k = 1024, sizes = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
      const i = Math.floor(Math.log(bytes) / Math.log(k));
      return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    };

    const invitedUsers = globalAccounts
      .filter(a => a.invitedBy === currentUser.username)
      .map(a => a.username.length <= 3 ? a.username + '***' : a.username.substring(0, 3) + '***');

    sendJSON({
      role: 'user',
      account: currentUser,
      invitedCount: invitedUsers.length,
      invitedUsers: invitedUsers,
      inviteRewardStr: formatSize(globalSettings.inviteReward)
    });
    return;
  }

  if (pathName === '/api/password' && req.method === 'POST') {
    if (!currentUser) return sendJSON({ error: '未登录' }, 401);
    getBody().then(data => {
      if (!data.newPassword) return sendJSON({ error: '密码不能为空' }, 400);
      const oldKey = `${currentUser.username}:${currentUser.password}`;
      currentUser.password = data.newPassword;
      // Bug Fix: 代理密码改变后必须更新 Map key，否则新密码无法认证
      accountByAuth.delete(oldKey);
      accountByAuth.set(`${currentUser.username}:${currentUser.password}`, currentUser);
      DataManager.save(globalAccounts);
      sendJSON({ success: true });
    });
    return;
  }

  if (pathName === '/api/web-password' && req.method === 'POST') {
    if (!currentUser) return sendJSON({ error: '未登录' }, 401);
    getBody().then(data => {
      if (!data.newPassword || !data.oldPassword) return sendJSON({ error: '请填写完整密码' }, 400);
      const currentWebPwd = currentUser.webPassword || currentUser.password;
      if (currentWebPwd !== data.oldPassword) return sendJSON({ error: '原密码错误' }, 400);
      currentUser.webPassword = data.newPassword; // 修改网页登录密码
      DataManager.save(globalAccounts);
      const t = Buffer.from(currentUser.username).toString('hex') + '.' + Buffer.from(currentUser.webPassword).toString('hex');
      sendJSON({ success: true, token: t });
    });
    return;
  }

  // ========== 账户激活 API ==========
  if (pathName === '/api/activate' && req.method === 'POST') {
    if (!currentUser) return sendJSON({ error: '未登录' }, 401);
    if (currentUser.role === 'vip') return sendJSON({ success: true, status: 'active' }); // VIP 永远不沉默
    currentUser.status = 'active';
    currentUser.lastUsed = Date.now();
    DataManager.save(globalAccounts);
    return sendJSON({ success: true, status: 'active' });
  }

  // ========== 管理员 API ==========
  if (pathName === '/api/admin/settings') {
    if (!isAdmin) return sendJSON({ error: '无权访问' }, 403);
    if (req.method === 'GET') return sendJSON(globalSettings);
    if (req.method === 'POST') {
      getBody().then(data => {
        if (data.defaultQuota !== undefined) globalSettings.defaultQuota = data.defaultQuota;
        if (data.inviteReward !== undefined) globalSettings.inviteReward = data.inviteReward;
        if (data.smtpHost !== undefined) globalSettings.smtpHost = data.smtpHost;
        if (data.smtpPort !== undefined) globalSettings.smtpPort = data.smtpPort;
        if (data.smtpUser !== undefined) globalSettings.smtpUser = data.smtpUser;
        if (data.smtpPass !== undefined) globalSettings.smtpPass = data.smtpPass;
        if (data.smtpSender !== undefined) globalSettings.smtpSender = data.smtpSender;
        if (data.announcementMode !== undefined) globalSettings.announcementMode = data.announcementMode;
        if (data.announcementTitle !== undefined) globalSettings.announcementTitle = data.announcementTitle;
        if (data.announcementContent !== undefined) globalSettings.announcementContent = data.announcementContent;
        if (data.announcementTime !== undefined) globalSettings.announcementTime = data.announcementTime;
        // 内容变更时自动更新 ID（用于 new 模式去重）
        if (data.announcementTitle !== undefined || data.announcementContent !== undefined) {
          globalSettings.announcementId = Date.now().toString();
        }
        DataManager.saveSettings();
        sendJSON({ success: true });
      });
      return;
    }
  }

  if (pathName === '/api/admin/broadcast' && req.method === 'POST') {
    if (!isAdmin) return sendJSON({ error: '无权访问' }, 403);
    if (!nodemailer) return sendJSON({ error: '服务端未安装 nodemailer' }, 500);
    if (!globalSettings.smtpHost || !globalSettings.smtpUser) {
      return sendJSON({ error: '系统未配置 SMTP 邮件服务' }, 400);
    }
    getBody().then(async data => {
      const { subject, htmlContent } = data;
      if (!subject || !htmlContent) return sendJSON({ error: '邮件主题或正文不能为空' }, 400);

      const transporter = nodemailer.createTransport({
        host: globalSettings.smtpHost,
        port: parseInt(globalSettings.smtpPort) || 465,
        secure: parseInt(globalSettings.smtpPort) === 465,
        auth: { user: globalSettings.smtpUser, pass: globalSettings.smtpPass }
      });

      // 异步后台发送，不阻塞当前请求
      const targets = globalAccounts.map(a => a.username);
      sendJSON({ success: true, count: targets.length });

      let successCount = 0, failCount = 0;
      for (let email of targets) {
        try {
          await transporter.sendMail({
            from: `"${globalSettings.smtpSender || 'S5 Proxy Admin'}" <${globalSettings.smtpUser}>`,
            to: email,
            subject: subject,
            html: htmlContent
          });
          successCount++;
        } catch (e) {
          console.error(`[Broadcast] Failed to send to ${email}:`, e.message);
          failCount++;
        }
        await new Promise(r => setTimeout(r, 500)); // 避免被退信，每封间隔 0.5 秒
      }
      console.log(`[Broadcast] 群发完成。成功: ${successCount}, 失败: ${failCount}`);
    });
    return;
  }

  if (pathName === '/api/admin/accounts') {
    if (!isAdmin) return sendJSON({ error: '无权访问' }, 403);
    if (req.method === 'GET') return sendJSON(globalAccounts);
    if (req.method === 'POST') {
      getBody().then(data => {
        data.forEach(acc => {
          const old = accountByName.get(acc.username);
          if (old && old.inviteCode) acc.inviteCode = old.inviteCode;
          else if (!acc.inviteCode) acc.inviteCode = generateInviteCode();
          if (old && old.invitedBy) acc.invitedBy = old.invitedBy;
          if (old && old.webPassword) acc.webPassword = old.webPassword;
          // 保留运行时字段（仅当新 payload 未提供时才使用旧值）
          if (!acc.role) acc.role = (old && old.role) ? old.role : 'normal';
          if (!acc.status) acc.status = (old && old.status) ? old.status : 'active';
          if (old && old.lastUsed) acc.lastUsed = old.lastUsed;
          if (old && old.createdAt) acc.createdAt = old.createdAt;
          else if (!acc.createdAt) acc.createdAt = Date.now();
        });
        globalAccounts = data;
        rebuildIndex();
        DataManager.save(globalAccounts);
        sendJSON({ success: true });
      });
      return;
    }
  }

  if (pathName === '/api/admin/connections' && req.method === 'GET') {
    if (!isAdmin) return sendJSON({ error: '无权访问' }, 403);
    const conns = [];
    for (const [user, count] of userConnCount.entries()) {
      conns.push({ username: user, count });
    }
    return sendJSON(conns);
  }

  res.writeHead(404); res.end();
});

// ========== 原生 SOCKS5 协议 ==========
function handleSocks5(socket, initialBuffer) {
  let stage = 0;
  let authUser = null;

  // TCP 优化：禁用 Nagle 算法降低延迟，开启 keepAlive 防 NAT 断连
  // readableHighWaterMark 64KB：减少频繁背压触发，提升大文件吞吐
  socket.setNoDelay(true);
  socket.setKeepAlive(true, 30000);
  if (socket.readableHighWaterMark < 65536) {
    try { socket._readableState.highWaterMark = 65536; } catch (e) { }
  }
  // 握手超时：120 秒内没有完成认证则断开
  socket.setTimeout(120000);
  socket.once('timeout', () => socket.destroy());

  const onData = (data) => {
    try {
      if (stage === 0) {
        if (data[0] !== 0x05) return socket.destroy();
        let supportsAuth = false;
        for (let i = 2; i < 2 + data[1]; i++) { if (data[i] === 0x02) supportsAuth = true; }
        if (!supportsAuth) { socket.write(Buffer.from([0x05, 0xFF])); return socket.destroy(); }
        socket.write(Buffer.from([0x05, 0x02]));
        stage = 1;
      }
      else if (stage === 1) {
        if (data[0] !== 0x01) return socket.destroy();
        const uLen = data[1];
        const user = data.slice(2, 2 + uLen).toString('utf8');
        const pLen = data[2 + uLen];
        const pass = data.slice(3 + uLen, 3 + uLen + pLen).toString('utf8');

        const account = accountByAuth.get(`${user}:${pass}`);
        if (!account || account.trafficUsed >= account.trafficLimit) {
          socket.write(Buffer.from([0x01, 0x01]));
          return socket.destroy();
        }
        // 沉默账户拦截（VIP 不受限）
        if (account.status === 'silent' && account.role !== 'vip') {
          socket.write(Buffer.from([0x01, 0x01]));
          return socket.destroy();
        }
        // 单用户连接数上限
        const connCount = userConnCount.get(user) || 0;
        if (connCount >= MAX_CONN_PER_USER) {
          socket.write(Buffer.from([0x01, 0x01]));
          return socket.destroy();
        }
        userConnCount.set(user, connCount + 1);
        socket.once('close', () => {
          const c = userConnCount.get(user) || 1;
          if (c <= 1) userConnCount.delete(user);
          else userConnCount.set(user, c - 1);
        });
        // 更新最后使用时间（仅内存，定时写盘即可）
        account.lastUsed = Date.now();
        if (account.status !== 'active') account.status = 'active';

        authUser = account;
        socket.write(Buffer.from([0x01, 0x00]));
        stage = 2;
      }
      else if (stage === 2) {
        if (data[0] !== 0x05 || data[1] !== 0x01) {
          socket.write(Buffer.from([0x05, 0x07, 0x00, 0x01, 0, 0, 0, 0, 0, 0]));
          return socket.destroy();
        }

        let atyp = data[3], dstAddr, dstPort, offset = 4;

        if (atyp === 0x01) {
          dstAddr = `${data[4]}.${data[5]}.${data[6]}.${data[7]}`; offset += 4;
        } else if (atyp === 0x03) {
          const dLen = data[4]; dstAddr = data.slice(5, 5 + dLen).toString('utf8'); offset += 1 + dLen;
        } else if (atyp === 0x04) {
          // 原生支持 IPv6 地址，提升现代网络兼容性
          const parts = [];
          for (let i = 0; i < 16; i += 2) parts.push(data.readUInt16BE(4 + i).toString(16));
          dstAddr = parts.join(':'); offset += 16;
        } else {
          socket.write(Buffer.from([0x05, 0x08, 0x00, 0x01, 0, 0, 0, 0, 0, 0]));
          return socket.destroy();
        }

        dstPort = data.readUInt16BE(offset);
        socket.removeListener('data', onData);

        const connectTarget = (resolvedIp) => {
          const target = net.connect({ port: dstPort, host: resolvedIp, allowHalfOpen: false });

          // 极限速度优化：激进的 TCP 缓冲与保活策略
          target.setNoDelay(true); // 禁用 Nagle 算法，消除粘包延迟，极大降低首字节时间
          socket.setNoDelay(true);
          target.setKeepAlive(true, 15000); // 激进的保活，防止 NAT 悄悄丢弃连接
          socket.setKeepAlive(true, 15000);

          // 强行扩展流缓冲区 (HighWaterMark) 到 1MB，为 4K/8K 视频流和迅雷满速下载保驾护航
          try { target._readableState.highWaterMark = 1048576; } catch (e) { }
          try { target._writableState.highWaterMark = 1048576; } catch (e) { }
          try { socket._readableState.highWaterMark = 1048576; } catch (e) { }
          try { socket._writableState.highWaterMark = 1048576; } catch (e) { }

          target.setTimeout(30000); // 连接超时

          target.once('timeout', () => target.destroy());

          target.once('connect', () => {
            target.setTimeout(0);
            socket.setTimeout(0);
            socket.write(Buffer.from([0x05, 0x00, 0x00, 0x01, 0, 0, 0, 0, 0, 0]));

            // 开启底层 C++ Pipe 管道
            target.pipe(socket);
            socket.pipe(target);

            // 极致性能：零监听 data 事件，完全依靠系统底层 bytesRead 进行“无感知”统计
            if (authUser) {
              let lastSockRead = socket.bytesRead || 0;
              let lastTargetRead = 0;

              const trafficTimer = setInterval(() => {
                if (socket.destroyed && target.destroyed) return clearInterval(trafficTimer);
                const curSock = socket.bytesRead || 0;
                const curTarget = target.bytesRead || 0;
                const added = (curSock - lastSockRead) + (curTarget - lastTargetRead);

                if (added > 0) {
                  authUser.trafficUsed += added;
                  lastSockRead = curSock;
                  lastTargetRead = curTarget;
                  if (authUser.trafficUsed >= authUser.trafficLimit) {
                    socket.destroy(); target.destroy();
                    clearInterval(trafficTimer);
                  }
                }
              }, 2000);

              const onEnd = () => {
                clearInterval(trafficTimer);
                const curSock = socket.bytesRead || 0;
                const curTarget = target.bytesRead || 0;
                authUser.trafficUsed += Math.max(0, curSock - lastSockRead) + Math.max(0, curTarget - lastTargetRead);
                if (!target.destroyed) target.end();
                if (!socket.destroyed) socket.end();
              };

              socket.on('close', onEnd);
              target.on('close', onEnd);
            } else {
              socket.on('end', () => target.end());
              target.on('end', () => socket.end());
            }
          });

          target.on('error', () => {
            try { socket.write(Buffer.from([0x05, 0x05, 0x00, 0x01, 0, 0, 0, 0, 0, 0])); } catch (e) { }
            socket.destroy();
          });
        }; // end of connectTarget

        // 极致路由：直接 IP 则跳过解析；域名则走异步无阻塞 DNS
        if (atyp === 0x01 || atyp === 0x04) {
          connectTarget(dstAddr);
        } else {
          extremeResolveDns(dstAddr).then(connectTarget).catch(() => {
            try { socket.write(Buffer.from([0x05, 0x04, 0x00, 0x01, 0, 0, 0, 0, 0, 0])); } catch (e) { }
            socket.destroy();
          });
        }
      }
    } catch (err) { socket.destroy(); }
  };

  socket.on('data', onData);
  socket.on('error', () => { });
  if (initialBuffer) onData(initialBuffer);
}

// ========== 端口复用主入口 ==========
const mainServer = net.createServer((socket) => {
  socket.once('data', (buffer) => {
    if (buffer[0] === 0x05) handleSocks5(socket, buffer);
    else { httpServer.emit('connection', socket); socket.pause(); socket.unshift(buffer); socket.resume(); }
  });
  socket.on('error', () => { });
});

mainServer.listen(CONFIG.port, '0.0.0.0', () => console.log(`🚀 S5公益代理 就绪: 端口 ${CONFIG.port}`));

// 写盘节流：最少间隔 2 秒
let _saveThrottleTimer = null;
const throttledSave = () => {
  if (_saveThrottleTimer) return;
  _saveThrottleTimer = setTimeout(() => {
    _saveThrottleTimer = null;
    DataManager.save(globalAccounts);
  }, 2000);
};
setInterval(throttledSave, CONFIG.saveInterval);

// 沉默账户检测：每小时扫描，普通账户超过 3 天未使用则标为 silent
const SILENT_THRESHOLD = 3 * 24 * 60 * 60 * 1000;
const REMIND_THRESHOLD = 2 * 24 * 60 * 60 * 1000;

setInterval(() => {
  const now = Date.now();
  let changed = false;

  let transporter = null;
  if (nodemailer && globalSettings.smtpHost && globalSettings.smtpUser) {
    transporter = nodemailer.createTransport({
      host: globalSettings.smtpHost,
      port: parseInt(globalSettings.smtpPort) || 465,
      secure: parseInt(globalSettings.smtpPort) === 465,
      auth: { user: globalSettings.smtpUser, pass: globalSettings.smtpPass }
    });
  }

  globalAccounts.forEach(acc => {
    if (acc.role === 'vip') return;       // VIP 免疫

    const idleTime = acc.lastUsed ? (now - acc.lastUsed) : 0;

    // 如果用户近期有使用，重置提醒状态
    if (idleTime < REMIND_THRESHOLD && acc.reminderSent) {
      acc.reminderSent = false;
      changed = true;
    }

    if (acc.status === 'silent') return;  // 已沉默跳过

    if (idleTime > SILENT_THRESHOLD) {
      acc.status = 'silent';
      changed = true;
    } else if (idleTime > REMIND_THRESHOLD && !acc.reminderSent) {
      acc.reminderSent = true;
      changed = true;

      // 发送预警提醒
      if (transporter && acc.username.includes('@')) {
        const mailOptions = {
          from: globalSettings.smtpSender || globalSettings.smtpUser,
          to: acc.username,
          subject: 'S5公益代理 - 账户沉默预警提醒',
          html: `<div style="font-family: sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e2e8f0; border-radius: 12px;">
                  <h3 style="color: #0f172a;">您的代理账户即将进入沉默状态</h3>
                  <p style="color: #64748b; font-size: 14px; line-height: 1.8;">
                    ⚠️ <b>普通用户须知</b>：连续3天未使用账户，系统将标记为“不使用账户”，届时需你到后台手动激活，才能继续免费使用。<br><br>
                    ✅ <b>邀请3人自动升级VIP</b>：从此“永不沉默”，无需任何手动激活，账户永久在线。<br><br>
                    📱 本服务器对移动用户特别友好，流畅访问。
                  </p>
                 </div>`
        };
        transporter.sendMail(mailOptions).catch(err => console.error('[Reminder Error]', err.message));
      }
    }
  });
  if (changed) throttledSave();
}, 60 * 60 * 1000).unref();

// ========== 绝美前端 HTML ==========
function getHtml() {
  return `
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>S5公益代理 - 极速安全的网络</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
    
    :root {
      --primary: #4f46e5;
      --primary-hover: #4338ca;
      --secondary: #10b981;
      --bg: #f8fafc;
      --surface: #ffffff;
      --text: #0f172a;
      --text-light: #64748b;
      --border: #e2e8f0;
      --shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05), 0 8px 10px -6px rgba(0, 0, 0, 0.01);
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Inter', system-ui, sans-serif; background: var(--bg); color: var(--text); -webkit-font-smoothing: antialiased; line-height: 1.5; overflow-x: hidden; }
    
    /* Navbar */
    .navbar { background: rgba(255, 255, 255, 0.9); backdrop-filter: blur(12px); border-bottom: 1px solid var(--border); position: sticky; top: 0; width: 100%; z-index: 50; }
    .nav-container { max-width: 1200px; margin: 0 auto; padding: 1rem; display: flex; justify-content: space-between; align-items: center; }
    .logo { font-size: 1.25rem; font-weight: 800; background: linear-gradient(135deg, var(--primary), #0ea5e9); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
    .nav-links { display: flex; gap: 0.5rem; }
    
    /* Layout */
    .main-content { max-width: 1200px; margin: 2rem auto; padding: 0 1rem; min-height: calc(100vh - 140px); }
    .view { display: none; animation: fadeIn 0.4s ease; }
    .view.active { display: block; }
    @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }

    /* Hero Section */
    .hero { text-align: center; padding: 3rem 0; }
    .hero h1 { font-size: clamp(2rem, 5vw, 3.5rem); font-weight: 800; margin-bottom: 1rem; letter-spacing: -0.05em; color: var(--text); line-height: 1.2; }
    .hero p { font-size: clamp(1rem, 2vw, 1.25rem); color: var(--text-light); max-width: 600px; margin: 0 auto 2rem; padding: 0 1rem; }
    
    /* Components */
    .card { background: var(--surface); border-radius: 16px; padding: 1.5rem; box-shadow: var(--shadow); border: 1px solid var(--border); margin-bottom: 1.5rem; }
    .btn { display: inline-flex; align-items: center; justify-content: center; padding: 0.75rem 1.25rem; border-radius: 8px; font-weight: 600; cursor: pointer; transition: all 0.2s; border: none; font-size: 0.95rem; text-decoration: none; }
    .btn-primary { background: linear-gradient(135deg, var(--primary), #6366f1); color: white; box-shadow: 0 4px 12px rgba(79, 70, 229, 0.2); }
    .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 6px 16px rgba(79, 70, 229, 0.3); }
    .btn-outline { background: transparent; border: 1px solid var(--border); color: var(--text); }
    .btn-outline:hover { background: #f1f5f9; }
    .btn-sm { padding: 0.5rem 0.75rem; font-size: 0.85rem; }
    .btn-success { background: #10b981; color: white; border:1px solid transparent; }
    .btn-warning { background: #f59e0b; color: white; border:1px solid transparent; }
    .btn-danger { background: #ef4444; color: white; border:1px solid transparent; }
    .btn-info { background: #0ea5e9; color: white; border:1px solid transparent; }
    .btn:disabled { opacity: 0.6; cursor: not-allowed; }
    
    /* Forms */
    .form-group { margin-bottom: 1.25rem; text-align: left; }
    .form-label { display: block; font-size: 0.875rem; font-weight: 600; margin-bottom: 0.5rem; color: var(--text); }
    .form-input { width: 100%; padding: 0.75rem 1rem; border-radius: 8px; border: 1px solid var(--border); font-size: 1rem; transition: border-color 0.2s; outline: none; background: #f8fafc; }
    .form-input:focus { border-color: var(--primary); background: #fff; box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1); }
    
    /* Grid & Stats */
    .grid-3 { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 1.5rem; }
    .stat-card { background: var(--surface); border-radius: 12px; padding: 1.25rem; border: 1px solid var(--border); }
    .stat-title { font-size: 0.85rem; font-weight: 600; color: var(--text-light); text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 0.25rem; }
    .stat-value { font-size: 1.5rem; font-weight: 800; color: var(--primary); word-break: break-all; }
    
    /* Progress */
    .progress-wrapper { margin-top: 0.5rem; width: 100%; min-width: 100px; }
    .progress-bar { width: 100%; height: 8px; background: var(--border); border-radius: 4px; overflow: hidden; }
    .progress-fill { height: 100%; background: linear-gradient(90deg, var(--secondary), var(--primary)); border-radius: 4px; transition: width 0.5s ease; }
    .progress-fill.danger { background: linear-gradient(90deg, #f59e0b, #ef4444); }

    /* Tables */
    .table-wrapper { width: 100%; overflow-x: auto; -webkit-overflow-scrolling: touch; }
    table { width: 100%; border-collapse: collapse; min-width: 600px; }
    th { text-align: left; padding: 0.75rem; font-size: 0.85rem; font-weight: 600; color: var(--text-light); border-bottom: 2px solid var(--border); white-space: nowrap; }
    td { padding: 0.75rem; border-bottom: 1px solid var(--border); vertical-align: middle; }
    .action-btns { display: flex; gap: 0.5rem; flex-wrap: wrap; }
    
    /* Modals */
    .modal-overlay { position: fixed; inset: 0; background: rgba(15, 23, 42, 0.5); backdrop-filter: blur(4px); display: none; align-items: center; justify-content: center; z-index: 100; padding: 1rem; }
    .modal { background: var(--surface); width: 100%; max-width: 450px; border-radius: 16px; padding: 1.5rem; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1); animation: fadeIn 0.3s ease; max-height: 90vh; overflow-y: auto; }
    
    /* Badges */
    .badge { display:inline-flex; align-items:center; gap:4px; padding:2px 10px; border-radius:99px; font-size:0.78rem; font-weight:700; }
    .badge-vip    { background:#fef3c7; color:#92400e; }
    .badge-normal { background:#ede9fe; color:#5b21b6; }
    .badge-active { background:#d1fae5; color:#065f46; }
    .badge-silent { background:#fee2e2; color:#991b1b; }
    /* Silent warning banner */
    .silent-banner { background:linear-gradient(135deg,#fff7ed,#fef2f2); border:1.5px solid #fca5a5; border-radius:12px; padding:1rem 1.25rem; margin-bottom:1.5rem; display:flex; align-items:center; justify-content:space-between; gap:1rem; flex-wrap:wrap; }
    .silent-banner p { color:#991b1b; font-size:0.9rem; font-weight:500; margin:0; }
    /* Admin search */
    .admin-search-bar { display:flex; gap:0.75rem; margin-bottom:1.25rem; align-items:center; flex-wrap:wrap; }
    .admin-search-bar input { flex:1; min-width:200px; }
    /* Admin compact row */
    .user-row-info { display:flex; flex-direction:column; gap:2px; }
    .user-row-info .email { font-weight:700; font-size:0.9rem; word-break:break-all; }
    .user-row-info .meta  { font-size:0.75rem; color:var(--text-light); }
    /* Notice bar on home */
    .notice-bar { background:linear-gradient(90deg,#fffbeb,#fff7ed); border:1px solid #fde68a; border-radius:12px; padding:0.75rem 1.25rem; margin-bottom:1.5rem; font-size:0.88rem; color:#92400e; display:flex; align-items:center; gap:0.5rem; }
    @media (max-width: 640px) {
      .hero { padding: 2rem 0; }
      .nav-links .btn { padding: 0.5rem 0.75rem; font-size: 0.85rem; }
      .grid-3 { grid-template-columns: 1fr; }
    }
  </style>
</head>
<body>

  <nav class="navbar">
    <div class="nav-container">
      <div class="logo">S5公益代理</div>
      <div class="nav-links" id="nav-actions"></div>
    </div>
  </nav>

  <div class="main-content">
    
    <!-- Home View -->
    <div id="view-home" class="view active">
      <div class="notice-bar">⚠️ <span>普通账户 <strong>超过 3 天未使用</strong> 将自动进入「沉默状态」，届时无法连接代理。请前往用户后台手动激活。<strong>VIP 账户不受此限制（邀请 3 人注册成功即可自动成为 VIP）。</strong></span></div>
      <div class="hero">
        <h1>极速安全的代理网络</h1>
        <p>提供极其稳定的SOCKS5隧道加密服务，保护您的隐私数据，畅享无界高速体验。</p>
        <div style="display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap;">
          <button class="btn btn-primary" onclick="showModal('registerModal')">立即注册送流量</button>
          <button class="btn btn-outline" onclick="showModal('loginModal')">登录控制台</button>
        </div>
      </div>
    </div>

    <!-- User Dashboard View -->
    <div id="view-dashboard" class="view">
      <!-- 管理员查看用户时的返回按钮 -->
      <div id="admin-back-btn" style="display:none; margin-bottom:1rem;">
        <button class="btn btn-outline btn-sm" onclick="showView('view-admin')">🔙 返回管理列表</button>
      </div>
      <!-- 沉默账户警告横幅 -->
      <div id="silent-banner" class="silent-banner" style="display:none">
        <p>🔇 您的账户已进入<strong>沉默状态</strong>（超过 3 天未使用），当前无法连接代理服务。请点击右侧按钮重新激活。</p>
        <button class="btn btn-warning btn-sm" onclick="doActivate()" style="white-space:nowrap">🔓 立即激活</button>
      </div>
      <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem;">
        <div>
          <h2 style="font-size: 1.75rem; font-weight: 800;">欢迎回来，<span id="user-name" style="color: var(--primary);"></span>
            <span id="user-role-badge" style="margin-left:0.5rem; vertical-align:middle;"></span>
          </h2>
          <p style="color: var(--text-light); margin-top: 0.25rem; font-size: 0.9rem;">专属代理网络状态面板 · <span id="user-status-text"></span></p>
        </div>
      </div>

      <div class="grid-3">
        <div class="stat-card">
          <div class="stat-title">总流量额度</div>
          <div class="stat-value" id="user-total">0 GB</div>
        </div>
        <div class="stat-card">
          <div class="stat-title">已用流量</div>
          <div class="stat-value" id="user-used" style="color: #64748b;">0 GB</div>
        </div>
        <div class="stat-card">
          <div class="stat-title">剩余流量</div>
          <div class="stat-value" id="user-remain" style="color: var(--secondary);">0 GB</div>
        </div>
      </div>

      <div class="card">
        <h3 style="margin-bottom: 1rem; font-size: 1.1rem;">流量使用进度</h3>
        <div class="progress-bar">
          <div id="user-progress" class="progress-fill" style="width: 0%;"></div>
        </div>
        <p id="user-percent" style="text-align: right; font-size: 0.85rem; color: var(--text-light); margin-top: 0.5rem;">0%</p>
      </div>

      <div class="grid-3">
        <!-- User Security Settings Card -->
        <div class="card" style="margin-bottom:0">
          <div style="display:flex; justify-content:space-between; align-items:center;">
            <h3 style="font-size: 1.1rem;">账户安全</h3>
            <button class="btn btn-outline btn-sm" onclick="showModal('webPwdModal')">修改登录密码</button>
          </div>
        </div>

        <!-- Node Config Card -->
        <div class="card" style="margin-bottom:0; grid-column: span 2;">
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1rem;">
            <h3 style="font-size: 1.1rem;">代理节点配置信息</h3>
            <button class="btn btn-outline btn-sm" onclick="showModal('pwdModal')">修改代理密码</button>
          </div>
          <div style="background: #f1f5f9; padding: 1rem; border-radius: 8px; font-family: monospace; font-size: 0.9rem; line-height: 1.6; word-break: break-all; margin-bottom: 1.5rem;">
            <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap:0.5rem; margin-bottom:0.5rem;">
              <div><strong style="color:var(--text-light)">地址：</strong> <span id="s5-host"></span></div>
              <div><strong style="color:var(--text-light)">端口：</strong> <span id="s5-port"></span></div>
              <div><strong style="color:var(--text-light)">密码：</strong> <span id="s5-pass"></span></div>
            </div>
            <div><strong style="color:var(--text-light)">用户：</strong> <span id="s5-user"></span></div>
          </div>
          
          <div style="display:flex; justify-content:space-between; align-items:center; cursor:pointer; background:#f1f5f9; padding:0.75rem 1rem; border-radius:8px; margin-bottom:0.5rem; border:1px solid var(--border);" onclick="toggleFormatList()">
            <h4 style="font-size:0.95rem; margin:0; color:var(--text)">📁 一键导入 / 订阅格式 (点击展开)</h4>
            <span id="format-toggle-icon" style="font-size:0.8rem; color:var(--text-light); transition:transform 0.2s;">▼</span>
          </div>
          <div id="format-list-container" style="display:none; flex-direction:column; gap:0.5rem; margin-top:0.5rem;">
            <div style="display:flex; justify-content:space-between; align-items:center; background:#f8fafc; padding:0.5rem 1rem; border:1px solid var(--border); border-radius:8px; flex-wrap:wrap; gap:0.5rem;">
              <span style="font-weight:600; font-size:0.9rem;">通用标准格式 (URL)</span>
              <div style="display:flex; gap:0.5rem;">
                <button class="btn btn-outline btn-sm" onclick="viewNodeFormat('url')">查看格式</button>
                <button class="btn btn-primary btn-sm" onclick="copyNodeFormat('url')">复制</button>
              </div>
            </div>
            <div style="display:flex; justify-content:space-between; align-items:center; background:#f8fafc; padding:0.5rem 1rem; border:1px solid var(--border); border-radius:8px; flex-wrap:wrap; gap:0.5rem;">
              <span style="font-weight:600; font-size:0.9rem;">Shadowrocket (Base64)</span>
              <div style="display:flex; gap:0.5rem;">
                <button class="btn btn-outline btn-sm" onclick="viewNodeFormat('base64')">查看格式</button>
                <button class="btn btn-primary btn-sm" onclick="copyNodeFormat('base64')">复制</button>
              </div>
            </div>
            <div style="display:flex; justify-content:space-between; align-items:center; background:#f8fafc; padding:0.5rem 1rem; border:1px solid var(--border); border-radius:8px; flex-wrap:wrap; gap:0.5rem;">
              <span style="font-weight:600; font-size:0.9rem;">v2ray 专用格式 (Base64)</span>
              <div style="display:flex; gap:0.5rem;">
                <button class="btn btn-outline btn-sm" onclick="viewNodeFormat('base64_alt')">查看格式</button>
                <button class="btn btn-primary btn-sm" onclick="copyNodeFormat('base64_alt')">复制</button>
              </div>
            </div>
            <div style="display:flex; justify-content:space-between; align-items:center; background:#f8fafc; padding:0.5rem 1rem; border:1px solid var(--border); border-radius:8px; flex-wrap:wrap; gap:0.5rem;">
              <span style="font-weight:600; font-size:0.9rem;">Telegram 一键直连</span>
              <div style="display:flex; gap:0.5rem;">
                <button class="btn btn-info btn-sm" onclick="connectTg(currentAcc)" style="border:none">🚀 直连</button>
                <button class="btn btn-outline btn-sm" onclick="viewNodeFormat('tg')">查看格式</button>
                <button class="btn btn-primary btn-sm" onclick="copyNodeFormat('tg')">复制</button>
              </div>
            </div>
            <div style="display:flex; justify-content:space-between; align-items:center; background:#f8fafc; padding:0.5rem 1rem; border:1px solid var(--border); border-radius:8px; flex-wrap:wrap; gap:0.5rem;">
              <span style="font-weight:600; font-size:0.9rem;">Clash / Meta (YAML)</span>
              <div style="display:flex; gap:0.5rem;">
                <button class="btn btn-outline btn-sm" onclick="viewNodeFormat('clash')">查看格式</button>
                <button class="btn btn-primary btn-sm" onclick="copyNodeFormat('clash')">复制</button>
              </div>
            </div>
            <div style="display:flex; justify-content:space-between; align-items:center; background:#f8fafc; padding:0.5rem 1rem; border:1px solid var(--border); border-radius:8px; flex-wrap:wrap; gap:0.5rem;">
              <span style="font-weight:600; font-size:0.9rem;">纯文本格式 (IP优先)</span>
              <div style="display:flex; gap:0.5rem;">
                <button class="btn btn-outline btn-sm" onclick="viewNodeFormat('txt_ip')">查看格式</button>
                <button class="btn btn-primary btn-sm" onclick="copyNodeFormat('txt_ip')">复制</button>
              </div>
            </div>
            <div style="display:flex; justify-content:space-between; align-items:center; background:#f8fafc; padding:0.5rem 1rem; border:1px solid var(--border); border-radius:8px; flex-wrap:wrap; gap:0.5rem;">
              <span style="font-weight:600; font-size:0.9rem;">纯文本格式 (账号优先)</span>
              <div style="display:flex; gap:0.5rem;">
                <button class="btn btn-outline btn-sm" onclick="viewNodeFormat('txt_user')">查看格式</button>
                <button class="btn btn-primary btn-sm" onclick="copyNodeFormat('txt_user')">复制</button>
              </div>
            </div>
            <div style="display:flex; justify-content:space-between; align-items:center; background:#f8fafc; padding:0.5rem 1rem; border:1px solid var(--border); border-radius:8px; flex-wrap:wrap; gap:0.5rem;">
              <span style="font-weight:600; font-size:0.9rem;">Surge (配置片段)</span>
              <div style="display:flex; gap:0.5rem;">
                <button class="btn btn-outline btn-sm" onclick="viewNodeFormat('surge')">查看格式</button>
                <button class="btn btn-primary btn-sm" onclick="copyNodeFormat('surge')">复制</button>
              </div>
            </div>
            <div style="display:flex; justify-content:space-between; align-items:center; background:#f8fafc; padding:0.5rem 1rem; border:1px solid var(--border); border-radius:8px; flex-wrap:wrap; gap:0.5rem;">
              <span style="font-weight:600; font-size:0.9rem;">Quantumult X (圈X)</span>
              <div style="display:flex; gap:0.5rem;">
                <button class="btn btn-outline btn-sm" onclick="viewNodeFormat('quanx')">查看格式</button>
                <button class="btn btn-primary btn-sm" onclick="copyNodeFormat('quanx')">复制</button>
              </div>
            </div>
          </div>
        </div>
        
        <!-- Invite System Card -->
        <div class="card" style="margin-bottom:0">
          <h3 style="margin-bottom: 1rem; font-size: 1.1rem;">邀请送流量</h3>
          <p style="color: var(--text-light); font-size: 0.9rem; margin-bottom: 1rem;">邀请好友注册，每成功邀请一人，您将额外获得 <span id="ui-invite-reward" style="color:var(--primary);font-weight:600"></span> 高速流量！</p>
          
          <div style="margin-bottom: 1rem;">
            <label class="form-label">您的专属邀请链接</label>
            <div style="display:flex; gap:0.5rem">
              <input type="text" id="my-invite-code" class="form-input" readonly style="background:#fff; text-align:center; font-weight:600; font-size:0.9rem; color:var(--primary)">
              <button class="btn btn-outline" onclick="copyInviteCode()">复制链接</button>
            </div>
          </div>
          
          <div>
            <label class="form-label">已邀请人数</label>
            <div style="display:flex; justify-content:space-between; align-items:center; padding: 0.75rem 1rem; background:#fff; border:1px solid var(--border); border-radius:8px;">
              <span style="font-size:1.25rem; font-weight:800; color:var(--primary)" id="my-invite-count">0</span>
              <button class="btn btn-sm btn-outline" onclick="showModal('invitedListModal')">查看明细</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Admin View -->
    <div id="view-admin" class="view">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; flex-wrap: wrap; gap: 1rem;">
        <h2 style="font-size: 1.75rem; font-weight: 800;">管理员控制台</h2>
        <div style="display:flex; gap:0.5rem">
          <button class="btn btn-info btn-sm" onclick="showConnections()">🔌 在线用户</button>
          <button class="btn btn-warning btn-sm" onclick="showModal('broadcastModal')">📢 一键发通知</button>
          <button class="btn btn-outline btn-sm" onclick="openSettingsModal()">&#9881; 全局配置</button>
          <button class="btn btn-primary btn-sm" onclick="adminEdit(-1)">&#43; 新增用户</button>
        </div>
      </div>
      <div class="admin-search-bar">
        <input type="text" id="admin-search" class="form-input" placeholder="🔍 搜索邮箱账号..." oninput="adminPage=1; renderAdmin()" style="font-size:0.9rem">
        <select id="admin-sort" class="form-input" style="width:auto; flex:none; cursor:pointer;" onchange="adminPage=1; renderAdmin()">
          <option value="default">默认排序</option>
          <option value="invite_desc">按邀请人数降序</option>
          <option value="traffic_desc">按已用流量降序</option>
        </select>
        <span id="admin-count" style="white-space:nowrap; font-size:0.85rem; color:var(--text-light);"></span>
      </div>
      <div class="card" style="padding:0; overflow:hidden">
        <div class="table-wrapper" style="padding: 1.25rem;">
          <table>
            <thead><tr><th>账号信息</th><th>状态</th><th>流量 (已用/限额)</th><th>操作</th></tr></thead>
            <tbody id="admin-list"></tbody>
          </table>
        </div>
        <div id="admin-pagination" style="padding: 1rem 1.25rem; border-top: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; background: #f8fafc;">
          <button class="btn btn-outline btn-sm" onclick="adminPrevPage()">上一页</button>
          <span style="font-size:0.85rem; font-weight:600; color:var(--text-light)" id="admin-page-text">第 1 页</span>
          <button class="btn btn-outline btn-sm" onclick="adminNextPage()">下一页</button>
        </div>
      </div>
    </div>

  </div>

  <!-- Modals -->
  <div id="loginModal" class="modal-overlay">
    <div class="modal">
      <h3 style="font-size: 1.5rem; margin-bottom: 1.5rem; text-align: center;">用户登录</h3>
      <div class="form-group"><label class="form-label">邮箱账号</label><input type="email" id="login-email" class="form-input" placeholder="您的注册邮箱"></div>
      <div class="form-group"><label class="form-label">登录密码</label><input type="password" id="login-pwd" class="form-input" placeholder="请输入密码" onkeyup="if(event.key==='Enter') doLogin()"></div>
      <div style="display: flex; justify-content: space-between; margin-bottom: 1.5rem; font-size: 0.85rem;">
        <a href="javascript:void(0)" onclick="hideModal('loginModal');showModal('forgotPwdModal')" style="color:var(--primary); text-decoration:none;">忘记密码？</a>
        <a href="javascript:void(0)" onclick="hideModal('loginModal');showModal('registerModal')" style="color:var(--text-light); text-decoration:underline;">没有账号？立即注册</a>
      </div>
      <div style="display: flex; gap: 1rem;">
        <button class="btn btn-outline" style="flex: 1;" onclick="hideModal('loginModal')">取消</button>
        <button class="btn btn-primary" style="flex: 1;" onclick="doLogin()">登录</button>
      </div>
      <div style="text-align:center; margin-top: 1.5rem;">
        <a href="javascript:void(0)" onclick="hideModal('loginModal');showModal('adminLoginModal')" style="font-size:0.85rem; color:var(--text-light); text-decoration:underline;">我是系统管理员</a>
      </div>
    </div>
  </div>

  <div id="registerModal" class="modal-overlay">
    <div class="modal">
      <h3 style="font-size: 1.5rem; margin-bottom: 0.5rem; text-align: center;">注册新账号</h3>
      <p style="text-align:center; color:var(--text-light); font-size:0.85rem; margin-bottom:1.5rem;">注册即赠送 <b id="ui-reg-limit" style="color:var(--primary)">1TB</b> 高速流量</p>
      
      <div class="form-group"><label class="form-label">邮箱账号</label><input type="email" id="reg-email" class="form-input" placeholder="请输入真实邮箱，用于找回密码"></div>
      
      <div class="form-group">
        <label class="form-label">验证码</label>
        <div style="display:flex; gap:0.5rem">
          <input type="text" id="reg-code" class="form-input" placeholder="6位验证码">
          <button class="btn btn-outline" id="btn-send-reg" onclick="reqSendCode('reg')" style="white-space:nowrap;">获取验证码</button>
        </div>
      </div>
      
      <div class="form-group"><label class="form-label">设置登录密码</label><input type="password" id="reg-pwd" class="form-input" placeholder="请输入复杂的密码"></div>
      <div class="form-group"><label class="form-label">邀请码 (选填)</label><input type="text" id="reg-invite" class="form-input" placeholder="如果没有可留空"></div>
      
      <div style="display: flex; gap: 1rem; margin-top: 1.5rem;">
        <button class="btn btn-outline" style="flex: 1;" onclick="hideModal('registerModal')">取消</button>
        <button class="btn btn-primary" style="flex: 1;" onclick="doRegister()">立即注册</button>
      </div>
      <div style="text-align:center; margin-top: 1.5rem;">
        <a href="javascript:void(0)" onclick="hideModal('registerModal');showModal('loginModal')" style="font-size:0.85rem; color:var(--text-light); text-decoration:underline;">已有账号？去登录</a>
      </div>
    </div>
  </div>

  <div id="forgotPwdModal" class="modal-overlay">
    <div class="modal">
      <h3 style="font-size: 1.5rem; margin-bottom: 1.5rem; text-align: center;">找回密码</h3>
      <div class="form-group"><label class="form-label">注册邮箱</label><input type="email" id="forgot-email" class="form-input" placeholder="请输入您的邮箱账号"></div>
      <div class="form-group">
        <label class="form-label">验证码</label>
        <div style="display:flex; gap:0.5rem">
          <input type="text" id="forgot-code" class="form-input" placeholder="6位验证码">
          <button class="btn btn-outline" id="btn-send-forgot" onclick="reqSendCode('forgot')" style="white-space:nowrap;">获取验证码</button>
        </div>
      </div>
      <div class="form-group"><label class="form-label">新登录密码</label><input type="password" id="forgot-pwd" class="form-input" placeholder="请输入新密码"></div>
      <div style="display: flex; gap: 1rem; margin-top: 1.5rem;">
        <button class="btn btn-outline" style="flex: 1;" onclick="hideModal('forgotPwdModal');showModal('loginModal')">返回登录</button>
        <button class="btn btn-primary" style="flex: 1;" onclick="doResetPwd()">重置密码</button>
      </div>
    </div>
  </div>

  <div id="webPwdModal" class="modal-overlay">
    <div class="modal">
      <h3 style="font-size: 1.5rem; margin-bottom: 1.5rem;">修改网页登录密码</h3>
      <div class="form-group"><label class="form-label">原密码</label><input type="password" id="w-old" class="form-input" placeholder="请输入当前登录密码"></div>
      <div class="form-group"><label class="form-label">新密码</label><input type="password" id="w-new" class="form-input" placeholder="请输入新登录密码"></div>
      <div style="display: flex; gap: 1rem; margin-top: 1.5rem;">
        <button class="btn btn-outline" style="flex: 1;" onclick="hideModal('webPwdModal')">取消</button>
        <button class="btn btn-primary" style="flex: 1;" onclick="changeWebPwd()">确定修改</button>
      </div>
    </div>
  </div>

  <div id="adminLoginModal" class="modal-overlay">
    <div class="modal">
      <h3 style="font-size: 1.5rem; margin-bottom: 1.5rem; text-align: center;">系统管理员登录</h3>
      <div class="form-group"><label class="form-label">管理密码</label><input type="password" id="admin-pass" class="form-input" onkeyup="if(event.key==='Enter') doAdminLogin()"></div>
      <div style="display: flex; gap: 1rem; margin-top: 2rem;">
        <button class="btn btn-outline" style="flex: 1;" onclick="hideModal('adminLoginModal')">取消</button>
        <button class="btn btn-primary" style="flex: 1;" onclick="doAdminLogin()">登录</button>
      </div>
    </div>
  </div>

  <div id="pwdModal" class="modal-overlay">
    <div class="modal">
      <h3 style="font-size: 1.5rem; margin-bottom: 1.5rem;">修改 SOCKS5 代理密码</h3>
      <div class="form-group"><label class="form-label">新代理密码</label><input type="text" id="p-new" class="form-input" placeholder="仅用于连接代理软件"></div>
      <div style="display: flex; gap: 1rem; margin-top: 1.5rem;">
        <button class="btn btn-outline" style="flex: 1;" onclick="hideModal('pwdModal')">取消</button>
        <button class="btn btn-primary" style="flex: 1;" onclick="changePwd()">确定修改</button>
      </div>
    </div>
  </div>

  <div id="adminEditModal" class="modal-overlay">
    <div class="modal">
      <h3 style="font-size: 1.5rem; margin-bottom: 1.5rem;">编辑代理用户</h3>
      <input type="hidden" id="a-idx">
      <div class="form-group"><label class="form-label">邮箱账号</label><input type="text" id="a-user" class="form-input"></div>
      <div class="form-group"><label class="form-label">代理密码</label><input type="text" id="a-pass" class="form-input"></div>
      <div class="form-group"><label class="form-label">流量限额 (如: 10GB/1TB)</label><input type="text" id="a-limit" class="form-input" value="1TB"></div>
      <div class="form-group">
        <label class="form-label">账户类型</label>
        <select id="a-role" class="form-input" style="cursor:pointer">
          <option value="normal">👤 普通账户（受 3 天沉默规则）</option>
          <option value="vip">⭐ VIP 账户（永不沉默）</option>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">账户状态</label>
        <select id="a-status" class="form-input" style="cursor:pointer">
          <option value="active">✅ 正常（可连接）</option>
          <option value="silent">🔇 沉默（封禁连接）</option>
        </select>
      </div>
      <div style="display: flex; gap: 1rem; margin-top: 1.5rem;">
        <button class="btn btn-outline" style="flex: 1;" onclick="hideModal('adminEditModal')">取消</button>
        <button class="btn btn-primary" style="flex: 1;" onclick="adminSave()">保存配置</button>
      </div>
    </div>
  </div>

  <div id="settingsModal" class="modal-overlay">
    <div class="modal" style="max-width:550px;">
      <h3 style="font-size: 1.5rem; margin-bottom: 1.5rem;">全局与邮件配置设定</h3>
      <div class="form-group"><label class="form-label">新用户注册默认赠送流量</label>
        <input type="text" id="s-default-limit" class="form-input" placeholder="例如: 1TB">
      </div>
      <div class="form-group"><label class="form-label">成功邀请一人奖励流量</label>
        <input type="text" id="s-invite-reward" class="form-input" placeholder="例如: 100GB">
      </div>
      
      <div style="border-top:1px solid var(--border); margin:1.5rem 0; padding-top:1.5rem;">
        <h4 style="margin-bottom:1rem; color:var(--primary)">SMTP 邮件发信配置 (必须填写)</h4>
        <div class="form-group"><label class="form-label">SMTP 服务器地址 (Host)</label><input type="text" id="s-smtp-host" class="form-input" placeholder="例如: smtp.qq.com"></div>
        <div class="form-group"><label class="form-label">SMTP 端口 (Port)</label><input type="number" id="s-smtp-port" class="form-input" placeholder="通常为 465"></div>
        <div class="form-group"><label class="form-label">SMTP 账号 / 发件人邮箱</label><input type="text" id="s-smtp-user" class="form-input" placeholder="例如: 12345@qq.com"></div>
        <div class="form-group"><label class="form-label">SMTP 密码 / 授权码</label><input type="password" id="s-smtp-pass" class="form-input" placeholder="填入授权码"></div>
        <div class="form-group"><label class="form-label">发件人昵称展示</label><input type="text" id="s-smtp-sender" class="form-input" placeholder="例如: S5公益代理 <12345@qq.com>"></div>
      </div>

      <div style="border-top:1px solid var(--border); margin:1.5rem 0; padding-top:1.5rem;">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1rem;">
          <h4 style="color:var(--primary); margin:0;">📢 弹窗公告设置</h4>
        </div>
        <div class="form-group">
          <label class="form-label">展示频率</label>
          <select id="s-ann-mode" class="form-input" style="cursor:pointer;">
            <option value="disabled">🚫 关闭公告（不展示）</option>
            <option value="always">🔁 每次打开都展示</option>
            <option value="daily">📅 每天只展示一次</option>
            <option value="new">🆕 有新公告才展示</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">公告标题</label>
          <input type="text" id="s-ann-title" class="form-input" placeholder="例如：系统维护通知">
        </div>
        <div class="form-group">
          <label class="form-label" style="display:flex; justify-content:space-between; align-items:center;">
            <span>公告时间</span>
            <button onclick="fillNowTime()" style="font-size:0.78rem; color:var(--primary); background:none; border:none; cursor:pointer; padding:0; font-weight:600;">📅 填入当前北京时间</button>
          </label>
          <input type="text" id="s-ann-time" class="form-input" placeholder="例如：2026-05-02 15:00">
        </div>
        <div class="form-group">
          <label class="form-label">公告内容</label>
          <textarea id="s-ann-content" class="form-input" rows="4" placeholder="支持换行，内容会完整展示在弹窗中..." style="resize:vertical; min-height:100px;"></textarea>
        </div>
      </div>
      
      <div style="display: flex; gap: 1rem; margin-top: 1.5rem;">
        <button class="btn btn-outline" style="flex: 1;" onclick="hideModal('settingsModal')">取消</button>
        <button class="btn btn-primary" style="flex: 1;" onclick="saveSettings()">保存全部设置</button>
      </div>
    </div>
  </div>
  
  <div id="invitedListModal" class="modal-overlay">
    <div class="modal">
      <h3 style="font-size: 1.5rem; margin-bottom: 1rem;">您邀请的好友</h3>
      <div style="max-height:250px; overflow-y:auto; background:#f8fafc; border-radius:8px; border:1px solid var(--border); padding:0.5rem">
        <ul id="invited-users-list" style="list-style:none; padding:0; margin:0;"></ul>
      </div>
      <div style="margin-top: 1.5rem;">
        <button class="btn btn-outline" style="width:100%" onclick="hideModal('invitedListModal')">关闭窗口</button>
      </div>
    </div>
  </div>

  <div id="formatViewModal" class="modal-overlay" style="z-index:150;">
    <div class="modal">
      <h3 style="font-size: 1.25rem; margin-bottom: 1rem;" id="fv-title">查看配置格式</h3>
      <textarea id="fv-content" class="form-input" readonly style="min-height:120px; font-family:monospace; font-size:0.85rem; background:#f1f5f9; resize:vertical; word-break:break-all; outline:none; cursor:text;"></textarea>
      <div style="display: flex; gap: 1rem; margin-top: 1.5rem;">
        <button class="btn btn-outline" style="flex: 1;" onclick="hideModal('formatViewModal')">关闭窗口</button>
        <button class="btn btn-primary" style="flex: 1;" onclick="copyTextToClipboard(document.getElementById('fv-content').value, '配置已成功复制！')">复制配置</button>
      </div>
    </div>
  </div>

  <div id="connectionsModal" class="modal-overlay" style="z-index:150;">
    <div class="modal">
      <h3 style="font-size: 1.5rem; margin-bottom: 1rem;">当前在线用户</h3>
      <div style="max-height:300px; overflow-y:auto; background:#f8fafc; border-radius:8px; border:1px solid var(--border); padding:0.5rem">
        <table style="width:100%; border-collapse: collapse; min-width:unset;">
          <thead><tr><th style="padding:0.5rem; border-bottom:2px solid var(--border);">账号</th><th style="padding:0.5rem; text-align:right; border-bottom:2px solid var(--border);">连接数</th></tr></thead>
          <tbody id="connections-list"></tbody>
        </table>
      </div>
      <div style="margin-top: 1.5rem; display:flex; gap:1rem;">
        <button class="btn btn-outline" style="flex:1;" onclick="hideModal('connectionsModal')">关闭窗口</button>
        <button class="btn btn-primary" style="flex:1;" onclick="showConnections()">刷新数据</button>
      </div>
    </div>
  </div>

  <!-- 一键发通知弹窗 -->
  <div id="broadcastModal" class="modal-overlay" style="z-index:150;">
    <div class="modal" style="max-width: 600px;">
      <h3 style="font-size: 1.5rem; margin-bottom: 1.5rem;">全站邮件通知群发</h3>
      <div class="form-group">
        <label class="form-label">邮件主题</label>
        <input type="text" id="bc-subject" class="form-input" placeholder="例如：节点维护升级通知">
      </div>
      <div class="form-group">
        <label class="form-label">邮件正文 (支持 HTML 代码)</label>
        <textarea id="bc-content" class="form-input" style="min-height:220px; resize:vertical; font-family:monospace;" placeholder="请输入邮件正文，支持完整的 HTML 标签。例如：\n<h2>亲爱的用户：</h2>\n<p>我们的服务器将于今晚升级...</p>"></textarea>
      </div>
      <div style="display: flex; gap: 1rem; margin-top: 1.5rem;">
        <button class="btn btn-outline" style="flex: 1;" onclick="previewBroadcast()">👁️ 预览效果</button>
        <button class="btn btn-primary" style="flex: 1;" onclick="sendBroadcast()">🚀 立即发送群邮件</button>
      </div>
      <div style="margin-top: 1rem;">
        <button class="btn btn-outline" style="width: 100%;" onclick="hideModal('broadcastModal')">取消并关闭</button>
      </div>
    </div>
  </div>

  <!-- 邮件预览弹窗 -->
  <div id="broadcastPreviewModal" class="modal-overlay" style="z-index:160;">
    <div class="modal" style="max-width: 600px;">
      <h3 style="font-size: 1.5rem; margin-bottom: 1rem;">邮件预览</h3>
      <div style="background:#f8fafc; border:1px solid var(--border); border-radius:8px; padding:1.5rem; overflow-y:auto; max-height:50vh; color: #334155; line-height: 1.6;" id="bc-preview-box">
      </div>
      <div style="margin-top: 1.5rem;">
        <button class="btn btn-primary" style="width:100%" onclick="hideModal('broadcastPreviewModal')">返回编辑</button>
      </div>
    </div>
  </div>

  <!-- 公告弹窗 -->
  <div id="announcementModal" class="modal-overlay" style="z-index:200;">
    <div class="modal" style="max-width:520px; border-top: 4px solid var(--primary); padding:0; overflow:hidden;">
      <div style="padding: 1.5rem 1.5rem 0;">
        <div style="display:flex; align-items:flex-start; gap:0.75rem; margin-bottom:1rem;">
          <span style="font-size:1.75rem; line-height:1;">📢</span>
          <div style="flex:1;">
            <h3 id="ann-modal-title" style="font-size:1.2rem; font-weight:800; color:var(--text); margin:0 0 0.25rem;"></h3>
            <span id="ann-modal-time" style="font-size:0.8rem; color:var(--text-light);"></span>
          </div>
        </div>
      </div>
      <div style="padding: 0 1.5rem 1.5rem; max-height:60vh; overflow-y:auto;">
        <div id="ann-modal-content" style="font-size:0.95rem; color:#334155; line-height:1.8; white-space:pre-wrap; word-break:break-word; background:#f8fafc; border-radius:8px; padding:1rem;"></div>
      </div>
      <div style="padding: 1rem 1.5rem; border-top:1px solid var(--border); display:flex; gap:0.75rem;">
        <button class="btn btn-outline" style="flex:1;" onclick="hideAnnouncement()">我知道了</button>
        <button class="btn btn-primary" style="flex:1;" onclick="hideAnnouncement(true)">不再提醒</button>
      </div>
    </div>
  </div>

<script>
let token = localStorage.getItem('kp_token');
let currentRole = null, currentAcc = null, adminAccounts = [];
let invitedUsers = [];
let serverPort = window.location.port || 80;
let serverIp = window.location.hostname;
let adminPage = 1;
const adminPageSize = 10;

const API = async (path, method='GET', body=null) => {
  const headers = {};
  if (token) headers['Authorization'] = 'Bearer ' + token;
  if (body) headers['Content-Type'] = 'application/json';
  const res = await fetch(path, { method, headers, body: body ? JSON.stringify(body) : null });
  const data = await res.json().catch(()=>({}));
  if (!res.ok) throw new Error(data.error || '请求失败');
  return data;
};

const formatSize = (bytes) => {
  if (isNaN(bytes) || bytes === null || bytes === undefined) return '0 B';
  if (bytes === 0) return '0 B';
  const k = 1024, sizes = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  if (i >= sizes.length) return (bytes / Math.pow(k, sizes.length - 1)).toFixed(2) + ' ' + sizes[sizes.length - 1];
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

const parseSizeStr = (limitStr) => {
  const num = parseFloat(limitStr) || 1;
  const unitStr = (limitStr.match(/[a-zA-Z]+/) || ['TB'])[0].toUpperCase();
  const units = {'B':1, 'KB':1024, 'MB':1024**2, 'GB':1024**3, 'TB':1024**4, 'PB':1024**5};
  return Math.floor(num * (units[unitStr] || units['TB']));
};

const showView = (id) => { document.querySelectorAll('.view').forEach(v => v.classList.remove('active')); document.getElementById(id).classList.add('active'); updateNav(); };
const showModal = (id) => { document.getElementById(id).style.display = 'flex'; };
const hideModal = (id) => { document.getElementById(id).style.display = 'none'; };
const logout = () => { localStorage.removeItem('kp_token'); token = null; currentRole = null; showView('view-home'); };

const updateNav = () => {
  const nav = document.getElementById('nav-actions');
  if (currentRole === 'admin') nav.innerHTML = \`<button class="btn btn-outline btn-sm" onclick="logout()">退出管理员</button>\`;
  else if (currentRole === 'user') nav.innerHTML = \`<button class="btn btn-outline btn-sm" onclick="logout()">退出登录</button>\`;
  else nav.innerHTML = \`<button class="btn btn-outline btn-sm" onclick="showModal('loginModal')" style="margin-right:0.5rem">登录</button><button class="btn btn-primary btn-sm" onclick="showModal('registerModal')">注册</button>\`;
};

const copyTextToClipboard = (text, successMsg) => {
  if (navigator.clipboard && window.isSecureContext) { navigator.clipboard.writeText(text).then(() => alert(successMsg)).catch(() => fallbackCopyTextToClipboard(text, successMsg)); } 
  else { fallbackCopyTextToClipboard(text, successMsg); }
};
const fallbackCopyTextToClipboard = (text, successMsg) => {
  const textArea = document.createElement("textarea"); textArea.value = text; textArea.style.position = "fixed";
  document.body.appendChild(textArea); textArea.focus(); textArea.select();
  try { document.execCommand('copy'); alert(successMsg); } catch (err) { alert('❌ 复制失败: \\n' + text); }
  document.body.removeChild(textArea);
};

const getTgLink = (acc) => {
  return \`https://t.me/socks?server=\${serverIp}&port=\${serverPort}&user=\${encodeURIComponent(acc.username)}&pass=\${encodeURIComponent(acc.password)}\`;
};
const connectTg = (acc) => window.open(getTgLink(acc));
const copyTgLink = (acc) => copyTextToClipboard(getTgLink(acc), '📄 SOCKS5 代理链接已复制！');

const getNodeFormat = (type) => {
  const u = currentAcc.username;
  const p = currentAcc.password;
  if (type === 'url') return \`socks5://\${u}:\${p}@\${serverIp}:\${serverPort}\`;
  if (type === 'tg') return getTgLink(currentAcc);
  if (type === 'clash') return \`- name: "S5节点-\${u.substring(0,4)}"\\n  type: socks5\\n  server: \${serverIp}\\n  port: \${serverPort}\\n  username: \${u}\\n  password: \${p}\`;
  if (type === 'base64') {
    const raw = \`\${u}:\${p}@\${serverIp}:\${serverPort}\`;
    return \`socks5://\${btoa(raw)}?remarks=S5节点-\${u.substring(0,4)}\`;
  }
  if (type === 'base64_alt') return \`socks://\${btoa(u+':'+p)}@\${serverIp}:\${serverPort}?remarks=S5节点-\${u.substring(0,4)}\`;
  if (type === 'txt_ip') return \`\${serverIp}:\${serverPort}:\${u}:\${p}\`;
  if (type === 'txt_user') return \`\${u}:\${p}@\${serverIp}:\${serverPort}\`;
  if (type === 'surge') return \`S5节点-\${u.substring(0,4)} = socks5, \${serverIp}, \${serverPort}, username=\${u}, password=\${p}\`;
  if (type === 'quanx') return \`socks5=\${serverIp}:\${serverPort}, username=\${u}, password=\${p}, fast-open=false, udp-relay=false, tag=S5节点-\${u.substring(0,4)}\`;
  return '';
};

const toggleFormatList = () => {
  const container = document.getElementById('format-list-container');
  const icon = document.getElementById('format-toggle-icon');
  if (container.style.display === 'none') {
    container.style.display = 'flex';
    icon.style.transform = 'rotate(180deg)';
  } else {
    container.style.display = 'none';
    icon.style.transform = 'rotate(0deg)';
  }
};

const viewNodeFormat = (type) => {
  const titles = { 
    url: '通用标准格式 (URL)', base64: 'Shadowrocket (Base64)', tg: 'Telegram 直连链接', 
    clash: 'Clash / Meta (YAML)', txt_ip: '批量纯文本 (IP优先)', txt_user: '批量纯文本 (账号优先)',
    surge: 'Surge (配置片段)', quanx: 'Quantumult X (圈X)', base64_alt: 'v2ray 专用格式 (Base64)'
  };
  document.getElementById('fv-title').innerText = titles[type] || '配置格式';
  document.getElementById('fv-content').value = getNodeFormat(type);
  showModal('formatViewModal');
};

const copyNodeFormat = (type) => {
  copyTextToClipboard(getNodeFormat(type), '✅ 配置已成功复制到剪贴板！');
};

const copyInviteCode = () => {
  const inviteLink = window.location.origin + window.location.pathname + '?invite=' + currentAcc.inviteCode;
  copyTextToClipboard(inviteLink, '🎉 专属邀请链接已复制！快发给好友吧！');
};

// 邮箱发送验证码
const reqSendCode = async (type) => {
  const emailInput = document.getElementById(type === 'reg' ? 'reg-email' : 'forgot-email');
  const btn = document.getElementById(type === 'reg' ? 'btn-send-reg' : 'btn-send-forgot');
  const email = emailInput.value;
  if (!email) return alert('请先输入邮箱地址');
  btn.disabled = true; btn.innerText = '发送中...';
  try {
    await API('/api/send-code', 'POST', { email });
    alert('验证码发送成功，请前往邮箱查看（如未收到请检查垃圾邮件）');
    let s = 60;
    const it = setInterval(()=>{
      if(s<=0){ clearInterval(it); btn.disabled=false; btn.innerText='获取验证码'; }
      else { btn.innerText = s+'秒后重发'; s--; }
    }, 1000);
  } catch(e) {
    alert(e.message);
    btn.disabled = false; btn.innerText = '获取验证码';
  }
};

const doRegister = async () => {
  try {
    const email = document.getElementById('reg-email').value;
    const code = document.getElementById('reg-code').value;
    const webPassword = document.getElementById('reg-pwd').value;
    const invCode = document.getElementById('reg-invite').value.trim();
    const res = await API('/api/register', 'POST', { email, code, webPassword, inviteCode: invCode });
    token = res.token; localStorage.setItem('kp_token', token); 
    hideModal('registerModal'); init();
  } catch(e) { alert(e.message); }
};

const doLogin = async () => {
  try {
    const email = document.getElementById('login-email').value;
    const webPassword = document.getElementById('login-pwd').value;
    const res = await API('/api/login', 'POST', { email, webPassword });
    token = res.token; localStorage.setItem('kp_token', token); 
    hideModal('loginModal'); init();
  } catch(e) { alert(e.message); }
};

const doResetPwd = async () => {
  try {
    const email = document.getElementById('forgot-email').value;
    const code = document.getElementById('forgot-code').value;
    const newWebPassword = document.getElementById('forgot-pwd').value;
    await API('/api/forgot-password', 'POST', { email, code, newWebPassword });
    alert('密码重置成功，请使用新密码登录');
    hideModal('forgotPwdModal');
    showModal('loginModal');
  } catch(e) { alert(e.message); }
};

const changeWebPwd = async () => {
  try {
    const oldPassword = document.getElementById('w-old').value;
    const newPassword = document.getElementById('w-new').value;
    const res = await API('/api/web-password', 'POST', { oldPassword, newPassword });
    token = res.token; localStorage.setItem('kp_token', token); 
    alert('登录密码修改成功！'); hideModal('webPwdModal');
    document.getElementById('w-old').value = '';
    document.getElementById('w-new').value = '';
  } catch(e) { alert(e.message); }
};

const doAdminLogin = async () => {
  try {
    const pass = document.getElementById('admin-pass').value;
    const res = await API('/api/login-admin', 'POST', { password: pass });
    token = res.token; localStorage.setItem('kp_token', token); hideModal('adminLoginModal'); init();
  } catch(e) { alert(e.message); }
};

const changePwd = async () => {
  try {
    await API('/api/password', 'POST', { newPassword: document.getElementById('p-new').value });
    alert('代理密码修改成功！'); hideModal('pwdModal'); init();
  } catch(e) { alert(e.message); }
};

const init = async () => {
  try { 
    const cfg = await API('/api/config'); 
    document.getElementById('ui-reg-limit').innerText = formatSize(cfg.defaultQuota); 
    if (cfg.serverPort) serverPort = cfg.serverPort;
    if (cfg.serverIp && !cfg.serverIp.includes('未知')) serverIp = cfg.serverIp;
  } catch(e){}
  if (!token) return showView('view-home');
  try {
    const res = await API('/api/me');
    currentRole = res.role;
    if (res.role === 'admin') { adminAccounts = await API('/api/admin/accounts'); renderAdmin(); showView('view-admin'); } 
    else { 
      currentAcc = res.account; 
      invitedUsers = res.invitedUsers || [];
      document.getElementById('ui-invite-reward').innerText = res.inviteRewardStr;
      renderUser(); showView('view-dashboard'); 
    }
  } catch(e) { logout(); }
};

const renderUser = (isAdminView = false) => {
  document.getElementById('user-name').innerText = currentAcc.username;
  document.getElementById('user-total').innerText = formatSize(currentAcc.trafficLimit);
  document.getElementById('user-used').innerText  = formatSize(currentAcc.trafficUsed);
  const remain = Math.max(0, currentAcc.trafficLimit - currentAcc.trafficUsed);
  document.getElementById('user-remain').innerText = formatSize(remain);

  const per = Math.min(100, (currentAcc.trafficUsed / currentAcc.trafficLimit) * 100);
  const bar = document.getElementById('user-progress'); bar.style.width = per + '%';
  if (per > 90) bar.classList.add('danger'); else bar.classList.remove('danger');
  document.getElementById('user-percent').innerText = per.toFixed(1) + '%';

  // 角色强调强调展示
  const isVip    = currentAcc.role === 'vip';
  const isSilent = currentAcc.status === 'silent' && !isVip;
  document.getElementById('user-role-badge').innerHTML =
    isVip ? '<span class="badge badge-vip">⭐ VIP</span>' : '<span class="badge badge-normal">👤 普通</span>';
  document.getElementById('user-status-text').innerHTML =
    isSilent ? '<span style="color:#dc2626;font-weight:600">🔇 已沈默，请激活</span>' : '<span style="color:#059669">✅ 连接正常</span>';
  document.getElementById('silent-banner').style.display = isSilent ? 'flex' : 'none';

  // S5 信息
  document.getElementById('s5-host').innerText = serverIp;
  document.getElementById('s5-port').innerText = serverPort;
  document.getElementById('s5-user').innerText = currentAcc.username;
  document.getElementById('s5-pass').innerText = currentAcc.password;

  // 邀请信息
  const inviteLink = window.location.origin + window.location.pathname + '?invite=' + (currentAcc.inviteCode || '');
  document.getElementById('my-invite-code').value = inviteLink;
  document.getElementById('my-invite-count').innerText = invitedUsers.length;

  const ul = document.getElementById('invited-users-list');
  if (invitedUsers.length === 0) {
    ul.innerHTML = '<li style="padding:1rem; text-align:center; color:#64748b; font-size:0.9rem;">暂无邀请记录</li>';
  } else {
    ul.innerHTML = invitedUsers.map(u => \`<li style="padding:0.75rem 1rem; border-bottom:1px solid #e2e8f0; font-family:monospace; color:var(--primary)">👤 \${u}</li>\`).join('');
  }

  // Admin View UI adjustments
  const displayStyle = isAdminView ? 'none' : 'inline-flex';
  document.querySelectorAll('#view-dashboard .card .btn-outline').forEach(btn => {
    if (btn.innerText.includes('修改')) btn.style.display = displayStyle;
  });
  const activateBtn = document.querySelector('#silent-banner button');
  if (activateBtn) activateBtn.style.display = displayStyle;
};

const renderAdmin = () => {
  const q = (document.getElementById('admin-search')?.value || '').toLowerCase();
  const sort = document.getElementById('admin-sort')?.value || 'default';
  
  // 过滤
  let filtered = adminAccounts.filter(a => a.username.toLowerCase().includes(q));
  
  // 动态计算每个人的邀请数量
  const getInviteCount = (username) => adminAccounts.filter(a => a.invitedBy === username).length;
  
  // 排序
  if (sort === 'invite_desc') {
    filtered.sort((a, b) => getInviteCount(b.username) - getInviteCount(a.username));
  } else if (sort === 'traffic_desc') {
    filtered.sort((a, b) => (b.trafficUsed || 0) - (a.trafficUsed || 0));
  }

  const totalFiltered = filtered.length;
  const totalPages = Math.ceil(totalFiltered / adminPageSize) || 1;
  if (adminPage > totalPages) adminPage = totalPages;
  if (adminPage < 1) adminPage = 1;

  const countEl = document.getElementById('admin-count');
  if (countEl) countEl.innerText = q ? \`共 \${totalFiltered} / \${adminAccounts.length} 个账户\` : \`共 \${adminAccounts.length} 个账户\`;
  document.getElementById('admin-page-text').innerText = \`第 \${adminPage} / \${totalPages} 页\`;

  const startIndex = (adminPage - 1) * adminPageSize;
  const pageData = filtered.slice(startIndex, startIndex + adminPageSize);

  document.getElementById('admin-list').innerHTML = pageData.map((a) => {
    const realIdx = adminAccounts.indexOf(a);
    const per  = Math.min(100, (a.trafficUsed / a.trafficLimit * 100)).toFixed(1);
    const isVip    = a.role === 'vip';
    const isSilent = a.status === 'silent' && !isVip;
    const roleBadge   = isVip    ? '<span class="badge badge-vip">⭐ VIP</span>'   : '<span class="badge badge-normal">👤 普通</span>';
    const statusBadge = isSilent ? '<span class="badge badge-silent">🔇 沉默</span>' : '<span class="badge badge-active">✅ 正常</span>';
    const inviteCount = getInviteCount(a.username);
    return \`<tr>
      <td>
        <div class="user-row-info">
          <span class="email">\${a.username}</span>
          <span class="meta">密码: \${a.password} \${a.invitedBy ? '&nbsp;•&nbsp;🚀 被 '+a.invitedBy+'邀请' : ''} \${inviteCount>0 ? '&nbsp;•&nbsp;🎁 邀请了 '+inviteCount+' 人' : ''}</span>
        </div>
      </td>
      <td>\${roleBadge}&nbsp;\${statusBadge}</td>
      <td>
        <div style="font-size:0.82rem; margin-bottom:3px;">\${formatSize(a.trafficUsed)} / \${formatSize(a.trafficLimit)} (\${per}%)</div>
        <div class="progress-wrapper"><div class="progress-bar"><div class="progress-fill \${per>90?'danger':''}" style="width:\${per}%"></div></div></div>
      </td>
      <td>
        <div class="action-btns">
          <button class="btn btn-info    btn-sm" onclick="adminViewUser(\${realIdx})">查看</button>
          <button class="btn btn-primary btn-sm" onclick="adminEdit(\${realIdx})">编辑</button>
          <button class="btn btn-danger  btn-sm" onclick="adminDel(\${realIdx})">删除</button>
        </div>
      </td>
    </tr>\`;
  }).join('');
};

const showConnections = async () => {
  try {
    const res = await API('/api/admin/connections');
    const tbody = document.getElementById('connections-list');
    if (res.length === 0) {
      tbody.innerHTML = '<tr><td colspan="2" style="text-align:center; padding:1rem; color:#64748b;">暂无在线用户</td></tr>';
    } else {
      res.sort((a,b) => b.count - a.count);
      tbody.innerHTML = res.map(c => \`<tr>
        <td style="padding:0.5rem;border-bottom:1px solid var(--border);">\${c.username}</td>
        <td style="padding:0.5rem;border-bottom:1px solid var(--border);text-align:right;"><span class="badge badge-active" style="padding:0.2rem 0.5rem;">\${c.count}</span></td>
      </tr>\`).join('');
    }
    showModal('connectionsModal');
  } catch(e) { alert('获取在线用户失败: ' + e.message); }
};

const adminPrevPage = () => { if(adminPage > 1) { adminPage--; renderAdmin(); } };
const adminNextPage = () => { 
  const q = (document.getElementById('admin-search')?.value || '').toLowerCase();
  const total = adminAccounts.filter(a => a.username.toLowerCase().includes(q)).length;
  if(adminPage < Math.ceil(total / adminPageSize)) { adminPage++; renderAdmin(); } 
};

const adminViewUser = (idx) => {
  const acc = adminAccounts[idx];
  currentAcc = acc;
  invitedUsers = adminAccounts.filter(a => a.invitedBy === acc.username).map(a => a.username);
  document.getElementById('admin-back-btn').style.display = 'block';
  renderUser(true);
  showView('view-dashboard');
};

const adminEdit = (idx) => {
  document.getElementById('a-idx').value = idx;
  if (idx > -1) {
    const a = adminAccounts[idx];
    document.getElementById('a-user').value   = a.username;
    document.getElementById('a-pass').value   = a.password;
    document.getElementById('a-limit').value  = formatSize(a.trafficLimit);
    document.getElementById('a-role').value   = a.role   || 'normal';
    document.getElementById('a-status').value = a.status || 'active';
  } else {
    document.getElementById('a-user').value   = '';
    document.getElementById('a-pass').value   = '';
    document.getElementById('a-limit').value  = '1TB';
    document.getElementById('a-role').value   = 'normal';
    document.getElementById('a-status').value = 'active';
  }
  showModal('adminEditModal');
};

const adminSave = async () => {
  const idx = parseInt(document.getElementById('a-idx').value);
  const old = idx > -1 ? adminAccounts[idx] : {};
  const data = {
    username:     document.getElementById('a-user').value,
    password:     document.getElementById('a-pass').value,
    trafficLimit: parseSizeStr(document.getElementById('a-limit').value),
    trafficUsed:  old.trafficUsed || 0,
    expiry:       '永不过期',
    role:         document.getElementById('a-role').value   || 'normal',
    status:       document.getElementById('a-status').value || 'active',
    lastUsed:     old.lastUsed || Date.now()
  };
  if (idx > -1) adminAccounts[idx] = data; else adminAccounts.push(data);
  await API('/api/admin/accounts', 'POST', adminAccounts);
  hideModal('adminEditModal'); init();
};

const previewBroadcast = () => {
  const content = document.getElementById('bc-content').value;
  if (!content.trim()) return alert('邮件正文为空，无法预览');
  document.getElementById('bc-preview-box').innerHTML = content;
  showModal('broadcastPreviewModal');
};

const sendBroadcast = async () => {
  const subject = document.getElementById('bc-subject').value.trim();
  const htmlContent = document.getElementById('bc-content').value.trim();
  if (!subject || !htmlContent) return alert('邮件主题和正文不能为空');
  if (!confirm('⚠️ 警告：\\n此操作将向平台内【所有注册用户】发送邮件！\\n请再次确认内容是否无误，您确定要继续吗？')) return;
  
  try {
    const res = await API('/api/admin/broadcast', 'POST', { subject, htmlContent });
    alert(\`✅ 邮件群发任务已进入后台队列！\\n共计需要向 \${res.count} 个用户发送邮件。\\n为了防止被反垃圾系统拦截，系统将以每秒 2 封的速度在后台慢慢发送，您可以关闭此窗口了。\`);
    hideModal('broadcastModal');
    document.getElementById('bc-subject').value = '';
    document.getElementById('bc-content').value = '';
  } catch(e) {
    alert('发送失败: ' + e.message);
  }
};

// 激活沉默账户
const doActivate = async () => {
  try {
    await API('/api/activate', 'POST');
    currentAcc.status = 'active';
    renderUser();
    alert('✅ 账户已成功激活！您现在可以正常使用代理服务。');
  } catch(e) { alert(e.message); }
};

const openSettingsModal = async () => {
  try {
    const s = await API('/api/admin/settings');
    document.getElementById('s-default-limit').value = formatSize(s.defaultQuota);
    document.getElementById('s-invite-reward').value = formatSize(s.inviteReward);
    document.getElementById('s-smtp-host').value = s.smtpHost || '';
    document.getElementById('s-smtp-port').value = s.smtpPort || 465;
    document.getElementById('s-smtp-user').value = s.smtpUser || '';
    document.getElementById('s-smtp-pass').value = s.smtpPass || '';
    document.getElementById('s-smtp-sender').value = s.smtpSender || '';
    // 公告配置
    document.getElementById('s-ann-mode').value = s.announcementMode || 'disabled';
    document.getElementById('s-ann-title').value = s.announcementTitle || '';
    document.getElementById('s-ann-time').value = s.announcementTime || '';
    document.getElementById('s-ann-content').value = s.announcementContent || '';
    showModal('settingsModal');
  } catch(e){ alert('获取配置失败'); }
};

// 填入当前北京时间
const fillNowTime = () => {
  const now = new Date();
  const bj = new Date(now.getTime() + 8 * 60 * 60 * 1000);
  const fmt = bj.toISOString().replace('T', ' ').substring(0, 16);
  document.getElementById('s-ann-time').value = fmt;
};

const saveSettings = async () => {
  try {
    const limitBytes = parseSizeStr(document.getElementById('s-default-limit').value);
    const rewardBytes = parseSizeStr(document.getElementById('s-invite-reward').value);
    await API('/api/admin/settings', 'POST', { 
      defaultQuota: limitBytes, 
      inviteReward: rewardBytes,
      smtpHost: document.getElementById('s-smtp-host').value,
      smtpPort: parseInt(document.getElementById('s-smtp-port').value) || 465,
      smtpUser: document.getElementById('s-smtp-user').value,
      smtpPass: document.getElementById('s-smtp-pass').value,
      smtpSender: document.getElementById('s-smtp-sender').value,
      announcementMode: document.getElementById('s-ann-mode').value,
      announcementTitle: document.getElementById('s-ann-title').value,
      announcementTime: document.getElementById('s-ann-time').value,
      announcementContent: document.getElementById('s-ann-content').value
    });
    alert('全局设置保存成功'); hideModal('settingsModal'); init();
  } catch(e) { alert(e.message); }
};

const adminDel = async (idx) => {
  if(!confirm('确定删除此用户？')) return; adminAccounts.splice(idx, 1);
  await API('/api/admin/accounts', 'POST', adminAccounts); init();
};

// 加载并渲染公告弹窗
const loadAnnouncement = async () => {
  try {
    const ann = await API('/api/announcement');
    if (ann.mode === 'disabled') return;

    const nowDay = new Date().toISOString().substring(0, 10); // YYYY-MM-DD
    const lastDay = localStorage.getItem('ann_last_day') || '';
    const lastId  = localStorage.getItem('ann_last_id')  || '';
    const dismissed = localStorage.getItem('ann_dismissed') === ann.id;

    let shouldShow = false;
    if (ann.mode === 'always') {
      shouldShow = true;
    } else if (ann.mode === 'daily') {
      shouldShow = lastDay !== nowDay;
    } else if (ann.mode === 'new') {
      shouldShow = ann.id && lastId !== ann.id && !dismissed;
    }

    if (!shouldShow) return;

    document.getElementById('ann-modal-title').textContent = ann.title || '系统公告';
    document.getElementById('ann-modal-time').textContent = ann.time || '';
    document.getElementById('ann-modal-content').textContent = ann.content || '';
    // 延迟 800ms 弹出，让页面先加载完
    setTimeout(() => {
      document.getElementById('announcementModal').style.display = 'flex';
      window._annId = ann.id;
    }, 800);
  } catch(e) {}
};

// 关闭公告弹窗
const hideAnnouncement = (permanent = false) => {
  document.getElementById('announcementModal').style.display = 'none';
  const nowDay = new Date().toISOString().substring(0, 10);
  localStorage.setItem('ann_last_day', nowDay);
  if (window._annId) localStorage.setItem('ann_last_id', window._annId);
  if (permanent && window._annId) localStorage.setItem('ann_dismissed', window._annId);
};

init();
loadAnnouncement();

// 解析邀请链接并自动填入
window.addEventListener('DOMContentLoaded', () => {
  const urlParams = new URLSearchParams(window.location.search);
  const invite = urlParams.get('invite') || urlParams.get('inv');
  if (invite) {
    document.getElementById('reg-invite').value = invite;
    if (!token) {
      setTimeout(() => {
        showModal('registerModal');
      }, 500);
    }
  }
});

// 禁用右键菜单和常见的开发者快捷键
document.addEventListener('contextmenu', e => e.preventDefault());
document.addEventListener('keydown', e => {
  if (e.key === 'F12' || 
      (e.ctrlKey && e.shiftKey && ['I', 'J', 'C'].includes(e.key.toUpperCase())) || 
      (e.ctrlKey && ['U', 'S', 'P'].includes(e.key.toUpperCase()))) {
    e.preventDefault();
  }
});
</script></body></html>
`;
}