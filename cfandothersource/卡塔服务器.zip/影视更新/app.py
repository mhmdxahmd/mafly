import os
import sys
import subprocess
import time
import asyncio
import re

# ================= 配置区 =================
CHECK_INTERVAL_MINUTES = 5

API_ID = 
API_HASH = ""
BOT_TOKEN = ""
CHAT_ID = -1001680439011
# 【重要配置】话题帖子(Topic) ID
# 获取方法: 在 TG 群组内右键/长按对应话题 -> 复制链接，链接的最后一段即为 ID
# 如: https://t.me/c/12345/6789 ，则填写 6789。如果不需要分隔，填 None 即可。
TOPIC_ID_OK = 637  # 👈 需要填入数字，例如: 12
TOPIC_ID_FM = 635  # 👈 需要填入数字，例如: 34

ACCEL_PREFIX = "https://js.2017.de5.net/"
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"
# ==========================================

def install_dependencies():
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pyrogram", "tgcrypto", "httpx", "--quiet"])
    except Exception as e:
        pass

install_dependencies()

try:
    asyncio.get_running_loop()
except RuntimeError:
    asyncio.set_event_loop(asyncio.new_event_loop())

import httpx
from pyrogram import Client, enums

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
REPO_DIR = os.path.join(BASE_DIR, "版本库")
APP_DIR = os.path.join(BASE_DIR, "APP库")

for d in [REPO_DIR, APP_DIR]:
    os.makedirs(d, exist_ok=True)

from pyrogram.raw import functions

async def init_topics(app, chat_id):
    """装载硬编码的话题频道 ID"""
    threads = {"OK": TOPIC_ID_OK, "FM": TOPIC_ID_FM}
    print(f"[{time.strftime('%H:%M:%S')}] 🧲 已加载预设话题: OK={threads['OK']}, FM={threads['FM']}")
    return threads

def format_desc(desc):
    """将 Github Markdown 格式的更新日志转换为 TG HTML 格式"""
    if not desc: return "* 常规更新及BUG修复"
    lines = desc.split('\n')
    formatted = []
    for line in lines:
        line = line.strip()
        if not line: continue
        line = line.replace('<', '&lt;').replace('>', '&gt;')
        if line.startswith('- '):
            line = '* ' + line[2:]
        elif not line.startswith('* '):
            line = '* ' + line
        formatted.append(line)
    return "\n".join(formatted)

def parse_ok_assets(assets):
    """提取 Github Release 中的所有 apk 并为其分配标识"""
    links = {}
    files = {}
    for asset in assets:
        name = asset.get('name', '')
        url = asset.get('browser_download_url', '')
        files[name] = url
        
        # 精准匹配不同架构和版本
        if 'mobile-pro.apk' in name:
            links['Mobile 通用'] = url
        elif 'leanback-pro-v8a.apk' in name:
            links['TV 64'] = url
        elif 'leanback-pro.apk' in name:
            links['TV 32'] = url
        elif 'mobile-arm64_v8a.apk' in name:
            links['Mobile 64'] = url
        elif 'mobile-armeabi_v7a.apk' in name:
            links['Mobile 32'] = url
        elif 'leanback-arm64_v8a.apk' in name:
            links['TV 64'] = url
        elif 'leanback-armeabi_v7a.apk' in name:
            links['TV 32'] = url
        elif 'hisense.apk' in name:
            links['Hisense'] = url
    return links, files

async def download_and_send_apk(app, chat_id, thread_id, url, file_name, accel_prefix):
    """流式下载 APK 并立即发送，发送完即删除释放空间"""
    accel_url = accel_prefix + url
    save_path = os.path.join(APP_DIR, file_name)
    try:
        if os.path.exists(save_path):
            os.remove(save_path)
            
        print(f"[{time.strftime('%H:%M:%S')}] ⬇️ 开始下载: {file_name}")
        async with httpx.AsyncClient(follow_redirects=True, verify=False, timeout=120.0) as client:
            async with client.stream("GET", accel_url, headers={"User-Agent": UA}) as response:
                response.raise_for_status()
                with open(save_path, "wb") as f:
                    async for chunk in response.aiter_bytes(chunk_size=8192):
                        f.write(chunk)
                        
        print(f"[{time.strftime('%H:%M:%S')}] ⬆️ 发送文件: {file_name} (话题 ID: {thread_id})")
        if thread_id:
            await app.send_document(chat_id=chat_id, document=save_path, reply_to_message_id=thread_id)
        else:
            await app.send_document(chat_id=chat_id, document=save_path)
        print(f"[{time.strftime('%H:%M:%S')}] ✅ 发送成功: {file_name}")
        
    except Exception as e:
        print(f"[{time.strftime('%H:%M:%S')}] ❌ 处理 {file_name} 失败: {e}")
    finally:
        if os.path.exists(save_path):
            os.remove(save_path)
            print(f"[{time.strftime('%H:%M:%S')}] 🗑️ 释放空间: {file_name}")

async def build_and_send_summary(app, chat_id, thread_id, topic_key, title_top, title_sub, version, desc_html, links_dict, accel_prefix):
    """构造并发送精美的数据整理卡片，并自动撤旧置新"""
    text = f"<b>{title_top}</b>\n"
    text += f"🚀 <b>发现{title_sub}:</b> <code>{version}</code>\n\n"
    text += f"{desc_html}\n\n"
    text += f"-----------\n"
    text += f"📍 <b>原直链</b>\n"
    
    def render_row(label, keys):
        row_links = []
        for k in keys:
            if k in links_dict:
                disp = "通用(可模拟器)版" if "通用" in k else ("32" if "32" in k else ("64" if "64" in k else ("海信专用版" if "Hisense" in k else k)))
                url = links_dict[k]
                row_links.append(f"<a href='{url}'>{disp}</a>")
        if row_links:
            return f"{label}：" + "  ".join(row_links) + "\n"
        return ""

    text += render_row("手机/平板", ['Mobile 通用', 'Mobile 32', 'Mobile 64'])
    text += render_row("电视(TV)", ['TV 通用', 'TV 32', 'TV 64'])
    text += render_row("其他", ['Hisense'])
    
    text += f"\n⚡ <b>代理链</b>\n"
    def render_accel_row(label, keys):
        row_links = []
        for k in keys:
            if k in links_dict:
                disp = "通用(可模拟器)版" if "通用" in k else ("32" if "32" in k else ("64" if "64" in k else ("海信专用版" if "Hisense" in k else k)))
                url = accel_prefix + links_dict[k]
                row_links.append(f"<a href='{url}'>{disp}</a>")
        if row_links:
            return f"{label}：" + "  ".join(row_links) + "\n"
        return ""
        
    text += render_accel_row("手机/平板", ['Mobile 通用', 'Mobile 32', 'Mobile 64'])
    text += render_accel_row("电视(TV)", ['TV 通用', 'TV 32', 'TV 64'])
    text += render_accel_row("其他", ['Hisense'])

    # 1. 发送新消息
    if thread_id:
        msg = await app.send_message(chat_id=chat_id, text=text, parse_mode=enums.ParseMode.HTML, disable_web_page_preview=True, reply_to_message_id=thread_id)
    else:
        msg = await app.send_message(chat_id=chat_id, text=text, parse_mode=enums.ParseMode.HTML, disable_web_page_preview=True)
    print(f"[{time.strftime('%H:%M:%S')}] 💌 汇总卡片发送完毕: {version}")

    # 2. 撤销上一次的置顶并记录全新的置顶
    last_pinned_file = os.path.join(REPO_DIR, f"{topic_key}_pinned.txt")
    if os.path.exists(last_pinned_file):
        try:
            with open(last_pinned_file, 'r', encoding='utf-8') as f:
                old_msg_id = int(f.read().strip())
            await app.unpin_chat_message(chat_id=chat_id, message_id=old_msg_id)
            print(f"[{time.strftime('%H:%M:%S')}] 📌 解除旧置顶 (ID: {old_msg_id})")
        except Exception as e:
            print(f"[{time.strftime('%H:%M:%S')}] ⚠️ 解除旧置顶失败: {e}")
            
    try:
        await app.pin_chat_message(chat_id=chat_id, message_id=msg.id, disable_notification=False)
        print(f"[{time.strftime('%H:%M:%S')}] 📌 成功置顶新卡片 (ID: {msg.id})")
        with open(last_pinned_file, 'w', encoding='utf-8') as f:
            f.write(str(msg.id))
    except Exception as e:
        print(f"[{time.strftime('%H:%M:%S')}] ⚠️ 置顶新消息失败: {e}")


async def check_fongmi(app, client, threads):
    """监控最新的蜂蜜(合并手机和电视版，一次性发送)"""
    thread_id = threads.get("FM")
    
    mob_updated = False
    tv_updated = False
    name_ver = "未知"
    desc_mob = ""
    desc_tv = ""
    ver_mob = ""
    ver_tv = ""
    
    # 手机版检测
    try:
        r_mob = await client.get("https://raw.githubusercontent.com/FongMi/Release/fongmi/apk/mobile.json", timeout=15)
        if r_mob.status_code == 200:
            mob_data = r_mob.json()
            ver_mob = str(mob_data.get('code', ''))
            name_ver = mob_data.get('name', ver_mob)
            desc_mob = mob_data.get('desc', '')
            record_file = os.path.join(REPO_DIR, "fongmi_mobile.txt")
            if os.path.exists(record_file):
                with open(record_file, 'r', encoding='utf-8') as f:
                    if f.read().strip() != ver_mob: mob_updated = True
            else: mob_updated = True
    except: pass

    # 电视版检测
    try:
        r_tv = await client.get("https://raw.githubusercontent.com/FongMi/Release/fongmi/apk/leanback.json", timeout=15)
        if r_tv.status_code == 200:
            tv_data = r_tv.json()
            ver_tv = str(tv_data.get('code', ''))
            if name_ver == "未知": name_ver = tv_data.get('name', ver_tv)
            desc_tv = tv_data.get('desc', '')
            record_file = os.path.join(REPO_DIR, "fongmi_tv.txt")
            if os.path.exists(record_file):
                with open(record_file, 'r', encoding='utf-8') as f:
                    if f.read().strip() != ver_tv: tv_updated = True
            else: tv_updated = True
    except: pass

    if mob_updated or tv_updated:
        print(f"[{time.strftime('%H:%M:%S')}] 🚀 发现蜂蜜更新: 手机({mob_updated}) 电视({tv_updated})")
        
        links = {
            'Mobile 64': "https://raw.githubusercontent.com/FongMi/Release/fongmi/apk/mobile-arm64_v8a.apk",
            'Mobile 32': "https://raw.githubusercontent.com/FongMi/Release/fongmi/apk/mobile-armeabi_v7a.apk",
            'TV 64': "https://raw.githubusercontent.com/FongMi/Release/fongmi/apk/leanback-arm64_v8a.apk",
            'TV 32': "https://raw.githubusercontent.com/FongMi/Release/fongmi/apk/leanback-armeabi_v7a.apk"
        }
        
        if mob_updated:
            files_mob = {
                f"mobile-arm64_v8a_{name_ver}.apk": links['Mobile 64'],
                f"mobile-armeabi_v7a_{name_ver}.apk": links['Mobile 32']
            }
            for fname, furl in files_mob.items():
                await download_and_send_apk(app, CHAT_ID, thread_id, furl, fname, ACCEL_PREFIX)
            with open(os.path.join(REPO_DIR, "fongmi_mobile.txt"), "w", encoding='utf-8') as f: f.write(ver_mob)

        if tv_updated:
            files_tv = {
                f"leanback-arm64_v8a_{name_ver}.apk": links['TV 64'],
                f"leanback-armeabi_v7a_{name_ver}.apk": links['TV 32']
            }
            for fname, furl in files_tv.items():
                await download_and_send_apk(app, CHAT_ID, thread_id, furl, fname, ACCEL_PREFIX)
            with open(os.path.join(REPO_DIR, "fongmi_tv.txt"), "w", encoding='utf-8') as f: f.write(ver_tv)

        merged_desc = ""
        if mob_updated and desc_mob:
            merged_desc += "* [App]\n" + desc_mob + "\n"
        if tv_updated and desc_tv:
            merged_desc += "* [Leanback]\n" + desc_tv + "\n"
        if not merged_desc: merged_desc = desc_mob or desc_tv or ""

        await build_and_send_summary(app, CHAT_ID, thread_id, "fm", "TVB/影视(蜂蜜版)", "蜂蜜新版本 (全平台)", name_ver, format_desc(merged_desc.strip()), links, ACCEL_PREFIX)

async def check_ok_releases(app, client, threads):
    """监控 lystv/fmapp Releases，提取普通版与 PRO 版"""
    thread_id = threads.get("OK")
    try:
        r = await client.get("https://api.github.com/repos/lystv/fmapp/releases", timeout=15)
        if r.status_code != 200:
            return
        releases = r.json()
    except Exception as e:
        print(f"[{time.strftime('%H:%M:%S')}] ⚠️ 获取 OK Release 失败: {e}")
        return

    if not isinstance(releases, list): return

    latest_pro = None
    latest_normal = None
    for rel in releases:
        tag = rel.get("tag_name", "")
        if "-pro" in tag.lower() and latest_pro is None:
            latest_pro = rel
        elif "-pro" not in tag.lower() and latest_normal is None:
            latest_normal = rel
            
        if latest_pro and latest_normal: break

    # ================= OK Pro版 =================
    if latest_pro:
        tag = latest_pro.get("tag_name", "")
        desc = latest_pro.get("body", "")
        record_file = os.path.join(REPO_DIR, "ok_pro.txt")
        needs_update = False
        if os.path.exists(record_file):
            with open(record_file, 'r', encoding='utf-8') as f:
                if f.read().strip() != tag: needs_update = True
        else: needs_update = True

        if needs_update:
            print(f"[{time.strftime('%H:%M:%S')}] 🚀 发现 OK(Pro版) 更新: {tag}")
            links, files = parse_ok_assets(latest_pro.get("assets", []))
            for fname, furl in files.items():
                await download_and_send_apk(app, CHAT_ID, thread_id, furl, fname, ACCEL_PREFIX)
            
            await build_and_send_summary(app, CHAT_ID, thread_id, "ok", "TVB/影视(OK)", "OK新版本 (PRO版)", tag, format_desc(desc), links, ACCEL_PREFIX)
            with open(record_file, "w", encoding='utf-8') as f: f.write(tag)

    # ================= OK 普通版 =================
    if latest_normal:
        tag = latest_normal.get("tag_name", "")
        desc = latest_normal.get("body", "")
        record_file = os.path.join(REPO_DIR, "ok_normal.txt")
        needs_update = False
        if os.path.exists(record_file):
            with open(record_file, 'r', encoding='utf-8') as f:
                if f.read().strip() != tag: needs_update = True
        else: needs_update = True

        if needs_update:
            print(f"[{time.strftime('%H:%M:%S')}] 🚀 发现 OK(普通版) 更新: {tag}")
            links, files = parse_ok_assets(latest_normal.get("assets", []))
            for fname, furl in files.items():
                await download_and_send_apk(app, CHAT_ID, thread_id, furl, fname, ACCEL_PREFIX)
            
            await build_and_send_summary(app, CHAT_ID, thread_id, "ok", "TVB/影视(OK)", "OK新版本 (普通版)", tag, format_desc(desc), links, ACCEL_PREFIX)
            with open(record_file, "w", encoding='utf-8') as f: f.write(tag)

async def check_all_updates(app, threads):
    async with httpx.AsyncClient(verify=False) as client:
        await check_fongmi(app, client, threads)
        await check_ok_releases(app, client, threads)

async def main():
    app = Client(os.path.join(BASE_DIR, "bot_session"), API_ID, API_HASH, bot_token=BOT_TOKEN, workdir=BASE_DIR)
    async with app:
        print(f"=======================================")
        print(f"🚀 自动推送系统 3.0 (Topic版) 启动中...")
        
        # 预检与挂载 Topics
        threads = await init_topics(app, CHAT_ID)
        
        print(f"🗂 监控源: 蜂蜜(手机/电视), OK(普通/PRO)")
        print(f"⏱ 监控周期: {CHECK_INTERVAL_MINUTES}分钟")
        print(f"🧲 推送话题分离: 启用")
        print(f"=======================================")
        
        while True:
            await check_all_updates(app, threads)
            print(f"[{time.strftime('%H:%M:%S')}] ⚡ 监控挂机中... 已完成最新轮次检测。")
            await asyncio.sleep(CHECK_INTERVAL_MINUTES * 60)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except Exception as e:
        print(f"\n程序异常退出: {e}")